# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Strong Obfuscation Rules
-repackageclasses ''
-allowaccessmodification
-dontusemixedcaseclassnames

# Keep data models that might be serialized (Firebase / Room)
-keep class com.example.data.models.** { *; }

# Keep composable functions from being completely stripped in a way that breaks Compose
-keep @androidx.compose.runtime.Composable class * { *; }

# Obfuscate everything else as much as possible
-optimizationpasses 5
-mergeinterfacesaggressively

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile
