package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.models.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatRepository(private val context: Context) {
    private var auth: FirebaseAuth? = null
    private var db: FirebaseFirestore? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _chats = MutableStateFlow<List<Chat>>(emptyList())
    val chats: StateFlow<List<Chat>> = _chats.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _chatMessages = MutableStateFlow<Map<String, List<Message>>>(emptyMap())
    val chatMessages: StateFlow<Map<String, List<Message>>> = _chatMessages.asStateFlow()
    
    private val _statuses = MutableStateFlow<List<UserStatusGroup>>(emptyList())
    val statuses: StateFlow<List<UserStatusGroup>> = _statuses.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    val typingStatus = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    val allUsers = MutableStateFlow<List<User>>(emptyList())

    init {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            auth = FirebaseAuth.getInstance()
            db = FirebaseFirestore.getInstance()

            auth?.addAuthStateListener { firebaseAuth ->
                val fbUser = firebaseAuth.currentUser
                if (fbUser != null) {
                    fetchUserFromFirestore(fbUser.uid)
                    startListeningToChats(fbUser.uid)
                } else {
                    _currentUser.value = null
                    _chats.value = emptyList()
                }
            }
        } catch (e: Exception) {
            Log.e("ChatRepository", "Firebase initialization failed. Missing google-services.json?", e)
            _error.value = "Firebase not connected. Please add google-services.json"
        }
    }

    private fun fetchUserFromFirestore(uid: String) {
        db?.collection("users")?.document(uid)?.addSnapshotListener { snapshot, _ ->
            if (snapshot != null && snapshot.exists()) {
                _currentUser.value = snapshot.toObject(User::class.java)
            }
        }
    }

    private fun startListeningToChats(uid: String) {
        db?.collection("chats")
            ?.whereArrayContains("participantIds", uid)
            ?.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    _error.value = "Failed to load chats"
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val chatList = snapshot.documents.mapNotNull { it.toObject(Chat::class.java) }
                    _chats.value = chatList
                }
            }
    }

    fun loadMessages(chatId: String) {
        db?.collection("chats")?.document(chatId)?.collection("messages")
            ?.orderBy("timestamp", Query.Direction.ASCENDING)
            ?.addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                if (snapshot != null) {
                    val messages = snapshot.documents.mapNotNull { it.toObject(Message::class.java) }
                    val currentMap = _chatMessages.value.toMutableMap()
                    currentMap[chatId] = messages
                    _chatMessages.value = currentMap
                }
            }
    }

    fun sendMessage(chatId: String, text: String, type: MessageType = MessageType.TEXT, mediaUri: android.net.Uri? = null, mediaFileName: String? = null, replyTo: Message? = null) {
        val user = _currentUser.value ?: return
        val dbInstance = db ?: return
        val messageRef = dbInstance.collection("chats").document(chatId).collection("messages").document()
        val message = Message(
            id = messageRef.id,
            chatId = chatId,
            senderId = user.uid,
            senderName = user.displayName,
            text = text,
            type = type,
            replyToId = replyTo?.id ?: "",
            timestamp = System.currentTimeMillis()
        )
        
        messageRef.set(message)
        
        dbInstance.collection("chats").document(chatId).update(
            mapOf(
                "lastMessage" to text,
                "lastMessageSenderId" to user.uid,
                "lastMessageSenderName" to user.displayName,
                "lastMessageTimestamp" to message.timestamp
            )
        )
    }

    fun login(email: String, pass: String, onComplete: (Boolean, String?) -> Unit) {
        val authInstance = auth
        if (authInstance == null) {
            _error.value = "Firebase not initialized. Please add google-services.json"
            onComplete(false, _error.value)
            return
        }
        
        _isLoading.value = true
        _error.value = null
        authInstance.signInWithEmailAndPassword(email, pass).addOnCompleteListener { task ->
            _isLoading.value = false
            if (task.isSuccessful) {
                onComplete(true, null)
            } else {
                _error.value = task.exception?.message ?: "Login failed"
                onComplete(false, _error.value)
            }
        }
    }

    fun register(email: String, pass: String, name: String, phone: String, about: String, onComplete: (Boolean, String?) -> Unit) {
        val authInstance = auth
        val dbInstance = db
        if (authInstance == null || dbInstance == null) {
            _error.value = "Firebase not initialized. Please add google-services.json"
            onComplete(false, _error.value)
            return
        }

        _isLoading.value = true
        _error.value = null
        authInstance.createUserWithEmailAndPassword(email, pass).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val uid = task.result?.user?.uid ?: return@addOnCompleteListener
                val newUser = User(uid = uid, email = email, displayName = name, phoneNumber = phone, about = about)
                dbInstance.collection("users").document(uid).set(newUser).addOnCompleteListener {
                    _isLoading.value = false
                    onComplete(true, null)
                }
            } else {
                _isLoading.value = false
                _error.value = task.exception?.message ?: "Registration failed"
                onComplete(false, _error.value)
            }
        }
    }

    fun logout() {
        auth?.signOut()
    }

    fun clearError() {
        _error.value = null
    }

    fun fastDemoLogin(name: String, about: String) {
        // dummy
    }

    fun getMessagesFlow(chatId: String): StateFlow<List<Message>> {
        val flow = MutableStateFlow<List<Message>>(emptyList())
        db?.collection("chats")?.document(chatId)?.collection("messages")
            ?.orderBy("timestamp", Query.Direction.ASCENDING)
            ?.addSnapshotListener { snapshot, error ->
                if (snapshot != null) {
                    flow.value = snapshot.documents.mapNotNull { it.toObject(Message::class.java) }
                }
            }
        return flow.asStateFlow()
    }

    fun markMessagesAsSeen(chatId: String) {}
    fun setTyping(chatId: String, isTyping: Boolean) {}
    fun toggleReaction(chatId: String, messageId: String, emoji: String) {}
    fun setChatWallpaper(chatId: String, wallpaper: String) {}
    fun createGroup(name: String, description: String, selectedUsers: List<User>, groupPhotoUri: android.net.Uri?, onComplete: (String) -> Unit) { onComplete("") }
    fun removeGroupMember(groupId: String, memberId: String) {}
    fun addGroupMember(groupId: String, user: User) {}
    fun markChatAsRead(chatId: String) {}
    fun togglePinChat(chatId: String) {}
    fun toggleArchiveChat(chatId: String) {}
    fun toggleMuteChat(chatId: String) {}
    fun deleteChat(chatId: String) {}
    fun getOrCreateAiChat(onComplete: (String) -> Unit) { onComplete("ai_chat") }
    fun updateProfile(displayName: String, about: String, photoUri: android.net.Uri?, onComplete: () -> Unit) { onComplete() }
    fun markStatusViewed(statusId: String, authorId: String) {}
    fun postStatus(type: StatusType, content: String = "", mediaUri: android.net.Uri? = null, backgroundColor: Long = 0L, fontIndex: Int = 0, caption: String = "", onComplete: () -> Unit) { onComplete() }
}
