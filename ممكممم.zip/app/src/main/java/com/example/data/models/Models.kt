package com.example.data.models

enum class MessageType {
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO,
    DOCUMENT
}

enum class MessageStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

enum class StatusType {
    TEXT,
    IMAGE,
    VIDEO
}

data class User(
    val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val photoUrl: String = "",
    val about: String = "Hey there! I am using WhatsApp Alostora Mohamed 👑",
    val isOnline: Boolean = true,
    val lastSeen: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

data class Message(
    val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderPhotoUrl: String = "",
    val text: String = "",
    val type: MessageType = MessageType.TEXT,
    val mediaUrl: String = "",
    val mediaLocalUri: String = "",
    val mediaFileName: String = "",
    val mediaSize: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT,
    val replyToId: String = "",
    val replyToText: String = "",
    val replyToSender: String = "",
    val readBy: List<String> = emptyList(),
    val readTimestamps: Map<String, Long> = emptyMap(),
    val deliveredTimestamps: Map<String, Long> = emptyMap(),
    val reactions: Map<String, String> = emptyMap() // userId -> emoji
)

data class Chat(
    val id: String = "",
    val isGroup: Boolean = false,
    val name: String = "",
    val photoUrl: String = "",
    val description: String = "",
    val adminIds: List<String> = emptyList(),
    val participantIds: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val participantPhotos: Map<String, String> = emptyMap(),
    val lastMessage: String = "",
    val lastMessageSenderId: String = "",
    val lastMessageSenderName: String = "",
    val lastMessageType: MessageType = MessageType.TEXT,
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val lastMessageStatus: MessageStatus = MessageStatus.SENT,
    val unreadCount: Int = 0,
    val pinned: Boolean = false,
    val muted: Boolean = false,
    val archived: Boolean = false,
    val wallpaper: String = "emerald_dark",
    val typingUsers: List<String> = emptyList()
)

data class StatusItem(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String = "",
    val type: StatusType = StatusType.TEXT,
    val content: String = "", // Text content or image/video URL
    val caption: String = "",
    val backgroundColor: Long = 0xFF005C4BL,
    val fontIndex: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val viewedBy: List<String> = emptyList()
)

data class UserStatusGroup(
    val userId: String,
    val userName: String,
    val userPhotoUrl: String,
    val items: List<StatusItem>,
    val hasUnseen: Boolean
)
