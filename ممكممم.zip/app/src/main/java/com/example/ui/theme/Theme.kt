package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.Black,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = TextPrimary,
    secondary = EmeraldLight,
    onSecondary = Color.Black,
    secondaryContainer = WhatsAppSurfaceContainer,
    onSecondaryContainer = TextPrimary,
    tertiary = GoldAccent,
    onTertiary = Color.Black,
    background = WhatsAppBackground,
    onBackground = TextPrimary,
    surface = WhatsAppSurface,
    onSurface = TextPrimary,
    surfaceVariant = WhatsAppSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DividerColor,
    outlineVariant = WhatsAppSurfaceContainer,
    error = DangerRed,
    onError = Color.White
)

private val LightColorScheme = darkColorScheme( // Keep default aesthetic consistently modern dark emerald
    primary = EmeraldPrimary,
    onPrimary = Color.Black,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = TextPrimary,
    secondary = EmeraldLight,
    onSecondary = Color.Black,
    secondaryContainer = WhatsAppSurfaceContainer,
    onSecondaryContainer = TextPrimary,
    tertiary = GoldAccent,
    onTertiary = Color.Black,
    background = WhatsAppBackground,
    onBackground = TextPrimary,
    surface = WhatsAppSurface,
    onSurface = TextPrimary,
    surfaceVariant = WhatsAppSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DividerColor,
    outlineVariant = WhatsAppSurfaceContainer,
    error = DangerRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Preserve bespoke WhatsApp Emerald aesthetic
    content: @Composable () -> Unit,
) {
    val colorScheme = DarkColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
