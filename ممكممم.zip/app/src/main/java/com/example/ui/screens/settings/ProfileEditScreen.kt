package com.example.ui.screens.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.repository.ChatRepository
import com.example.ui.components.UserAvatar
import com.example.ui.theme.DarkInputBackground
import com.example.ui.theme.DividerColor
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhatsAppBackground
import com.example.ui.theme.WhatsAppSurface
import com.example.ui.theme.WhatsAppSurfaceVariant

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileEditScreen(
    repository: ChatRepository,
    onBack: () -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val isLoading by repository.isLoading.collectAsState()

    var displayName by remember(currentUser) { mutableStateOf(currentUser?.displayName ?: "") }
    var about by remember(currentUser) { mutableStateOf(currentUser?.about ?: "") }
    var newPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var isSavedSuccessfully by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            newPhotoUri = uri
        }
    }

    val presetAbouts = listOf(
        "Available 🌟",
        "Busy ⚡",
        "At work 💼",
        "WhatsApp Alostora VIP 👑",
        "In a meeting 🤝",
        "Only urgent calls 📞",
        "Sleeping 🌙",
        "Can't talk, WhatsApp only 💬"
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_edit_screen"),
        containerColor = WhatsAppBackground,
        topBar = {
            Surface(color = WhatsAppSurface, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("profile_edit_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Profile",
                        color = TextPrimary,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Photo with Camera Badge
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    .testTag("profile_photo_edit_button"),
                contentAlignment = Alignment.BottomEnd
            ) {
                if (newPhotoUri != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(newPhotoUri)
                            .crossfade(true)
                            .build(),
                        contentDescription = "New Profile Photo",
                        modifier = Modifier
                            .size(130.dp)
                            .clip(CircleShape),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                } else {
                    UserAvatar(
                        photoUrl = currentUser?.photoUrl ?: "",
                        displayName = displayName.ifEmpty { "User" },
                        size = 130.dp
                    )
                }

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(EmeraldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Change photo",
                        tint = Color.Black,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Name Field
            OutlinedTextField(
                value = displayName,
                onValueChange = { displayName = it },
                label = { Text("Name") },
                supportingText = {
                    Text("This is not your username or pin. This name will be visible to your WhatsApp contacts.")
                },
                leadingIcon = {
                    Icon(Icons.Default.Person, contentDescription = "Name", tint = EmeraldPrimary)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = DarkInputBackground,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = WhatsAppSurfaceVariant,
                    unfocusedContainerColor = WhatsAppSurfaceVariant
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_name_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // About Bio Field
            OutlinedTextField(
                value = about,
                onValueChange = { about = it },
                label = { Text("About") },
                leadingIcon = {
                    Icon(Icons.Default.Info, contentDescription = "About", tint = EmeraldPrimary)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = DarkInputBackground,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = WhatsAppSurfaceVariant,
                    unfocusedContainerColor = WhatsAppSurfaceVariant
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_about_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Preset About Chips
            Text(
                text = "Select from presets:",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                presetAbouts.forEach { preset ->
                    SuggestionChip(
                        onClick = { about = preset },
                        label = { Text(preset, fontSize = 12.sp, color = TextPrimary) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = WhatsAppSurfaceVariant
                        ),
                        border = null
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Phone Field (Read-only representation)
            OutlinedTextField(
                value = currentUser?.phoneNumber ?: "+20 100 000 0000",
                onValueChange = {},
                readOnly = true,
                label = { Text("Phone") },
                leadingIcon = {
                    Icon(Icons.Default.Phone, contentDescription = "Phone", tint = EmeraldPrimary)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DarkInputBackground,
                    unfocusedBorderColor = DarkInputBackground,
                    focusedTextColor = TextSecondary,
                    unfocusedTextColor = TextSecondary,
                    focusedContainerColor = WhatsAppSurfaceVariant,
                    unfocusedContainerColor = WhatsAppSurfaceVariant
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(30.dp))

            // Save Button
            Button(
                onClick = {
                    repository.updateProfile(
                        displayName = displayName.ifBlank { "Alostora Member" },
                        about = about,
                        photoUri = newPhotoUri
                    ) {
                        isSavedSuccessfully = true
                    }
                },
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("profile_save_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                } else if (isSavedSuccessfully) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, contentDescription = "Saved", tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Profile Updated!", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text("Save Changes", color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
