package com.example.ui.screens.main

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.models.Chat
import com.example.data.models.MessageType
import com.example.data.models.UserStatusGroup
import com.example.data.repository.ChatRepository
import com.example.ui.components.ReadReceiptIcon
import com.example.ui.components.StatusRingAvatar
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatChatTime
import com.example.ui.theme.DarkInputBackground
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DividerColor
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.UnreadBadgeGreen
import com.example.ui.theme.WhatsAppBackground
import com.example.ui.theme.WhatsAppSurface
import com.example.ui.theme.WhatsAppSurfaceContainer
import com.example.ui.theme.WhatsAppSurfaceVariant

@Composable
fun MainScreen(
    repository: ChatRepository,
    onNavigateToChat: (String) -> Unit,
    onNavigateToCreateGroup: () -> Unit,
    onNavigateToStatusViewer: (String) -> Unit,
    onNavigateToTextStatus: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Chats, 1: Status, 2: Calls, 3: Settings
    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var chatFilter by remember { mutableStateOf("all") } // "all", "unread", "groups", "ai"
    var activeCallData by remember { mutableStateOf<Triple<String, String, Boolean>?>(null) } // Name, avatar/photo, isVideo
    var viewingArchived by remember { mutableStateOf(false) }
    var selectedChatForActions by remember { mutableStateOf<Chat?>(null) }

    val currentUser by repository.currentUser.collectAsState()
    val chats by repository.chats.collectAsState()
    val statuses by repository.statuses.collectAsState()

    // Filtered chats list (unarchived chats only, sorted by pinned then timestamp)
    val filteredChats = remember(chats, searchQuery, chatFilter) {
        chats.filter { chat ->
            val matchesSearch = if (searchQuery.isBlank()) true else {
                chat.name.contains(searchQuery, ignoreCase = true) ||
                        chat.lastMessage.contains(searchQuery, ignoreCase = true) ||
                        chat.description.contains(searchQuery, ignoreCase = true)
            }
            val matchesFilter = when (chatFilter) {
                "unread" -> chat.unreadCount > 0
                "groups" -> chat.isGroup
                "ai" -> chat.name.contains("AI", ignoreCase = true) || chat.name.contains("ذكاء", ignoreCase = true)
                else -> true
            }
            !chat.archived && matchesSearch && matchesFilter
        }.sortedWith(
            compareByDescending<Chat> { it.pinned }
                .thenByDescending { it.lastMessageTimestamp }
        )
    }

    // Archived chats list
    val archivedChats = remember(chats, searchQuery) {
        chats.filter { chat ->
            val matchesSearch = if (searchQuery.isBlank()) true else {
                chat.name.contains(searchQuery, ignoreCase = true) ||
                        chat.lastMessage.contains(searchQuery, ignoreCase = true)
            }
            chat.archived && matchesSearch
        }.sortedWith(
            compareByDescending<Chat> { it.pinned }
                .thenByDescending { it.lastMessageTimestamp }
        )
    }

    val totalArchivedCount = remember(chats) { chats.count { it.archived } }
    val totalUnreadChats = remember(chats) { chats.sumOf { if (it.unreadCount > 0) 1.toInt() else 0.toInt() } }
    val hasUnseenStatuses = remember(statuses, currentUser) {
        statuses.any { it.userId != currentUser?.uid && it.hasUnseen }
    }

    // If viewing archived view, show dedicated screen
    if (viewingArchived) {
        ArchivedChatsScreen(
            archivedChats = archivedChats,
            searchQuery = searchQuery,
            onSearchChange = { searchQuery = it },
            onBack = {
                viewingArchived = false
                searchQuery = ""
            },
            onChatClick = { chat ->
                repository.markChatAsRead(chat.id)
                onNavigateToChat(chat.id)
            },
            onChatLongClick = { chat ->
                selectedChatForActions = chat
            }
        )

        // Actions Dialog for long-press in archived
        selectedChatForActions?.let { chat ->
            ChatActionDialog(
                chat = chat,
                onDismiss = { selectedChatForActions = null },
                onTogglePin = { repository.togglePinChat(chat.id) },
                onToggleArchive = { repository.toggleArchiveChat(chat.id) },
                onToggleMute = { repository.toggleMuteChat(chat.id) },
                onDelete = { repository.deleteChat(chat.id) }
            )
        }
        return
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_screen"),
        containerColor = WhatsAppBackground,
        topBar = {
            WhatsAppMainTopBar(
                selectedTab = selectedTab,
                isSearchActive = isSearchActive,
                searchQuery = searchQuery,
                showMenu = showMenu,
                onSearchToggle = {
                    isSearchActive = !isSearchActive
                    if (!isSearchActive) searchQuery = ""
                },
                onSearchChange = { searchQuery = it },
                onMenuToggle = { showMenu = !showMenu },
                onMenuDismiss = { showMenu = false },
                onCameraClick = onNavigateToTextStatus,
                onNewGroup = {
                    showMenu = false
                    onNavigateToCreateGroup()
                },
                onProfileClick = {
                    showMenu = false
                    onNavigateToProfile()
                },
                onLogout = {
                    showMenu = false
                    repository.logout()
                    onLogout()
                }
            )
        },
        bottomBar = {
            WhatsAppBottomNavigationBar(
                selectedTab = selectedTab,
                unreadChatsCount = totalUnreadChats,
                hasUnseenStatus = hasUnseenStatuses,
                onTabSelected = { index ->
                    if (index == 4) {
                        selectedTab = 0
                        chatFilter = "groups"
                    } else {
                        if (index == 0) chatFilter = "all"
                        selectedTab = index
                    }
                }
            )
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> {
                    // Chat FAB
                    FloatingActionButton(
                        onClick = onNavigateToCreateGroup,
                        containerColor = EmeraldPrimary,
                        contentColor = DarkOnPrimary,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("fab_new_chat")
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "New Chat/Group")
                    }
                }
                1 -> {
                    // Status Dual FABs (Pencil + Camera)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SmallFloatingActionButton(
                            onClick = onNavigateToTextStatus,
                            containerColor = WhatsAppSurfaceContainer,
                            contentColor = TextPrimary,
                            shape = CircleShape,
                            modifier = Modifier.testTag("fab_text_status")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Text Status", modifier = Modifier.size(18.dp))
                        }
                        FloatingActionButton(
                            onClick = onNavigateToTextStatus,
                            containerColor = EmeraldPrimary,
                            contentColor = DarkOnPrimary,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("fab_camera_status")
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Camera Status")
                        }
                    }
                }
                2 -> {
                    // Call FAB
                    FloatingActionButton(
                        onClick = {
                            activeCallData = Triple("Alostora Mohamed 👑", "", false)
                        },
                        containerColor = EmeraldPrimary,
                        contentColor = DarkOnPrimary,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.testTag("fab_new_call")
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "New Call")
                    }
                }
                else -> {}
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // WhatsApp 3 Primary Tabs (Chats, Updates, Calls) when on messaging tabs
            if (selectedTab in 0..2) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = WhatsAppSurface,
                    contentColor = EmeraldPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = EmeraldPrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "CHATS",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selectedTab == 0) EmeraldPrimary else TextSecondary,
                                    fontSize = 14.sp
                                )
                                if (totalUnreadChats > 0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(EmeraldPrimary, CircleShape)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "$totalUnreadChats",
                                            color = DarkOnPrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        },
                        modifier = Modifier.testTag("main_tab_chats")
                    )

                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "UPDATES",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selectedTab == 1) EmeraldPrimary else TextSecondary,
                                    fontSize = 14.sp
                                )
                                if (hasUnseenStatuses) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .background(EmeraldLight, CircleShape)
                                    )
                                }
                            }
                        },
                        modifier = Modifier.testTag("main_tab_status")
                    )

                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Text(
                                "CALLS",
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedTab == 2) EmeraldPrimary else TextSecondary,
                                fontSize = 14.sp
                            )
                        },
                        modifier = Modifier.testTag("main_tab_calls")
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    ChatsTabContent(
                        chats = filteredChats,
                        archivedCount = totalArchivedCount,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        activeFilter = chatFilter,
                        onFilterSelect = { chatFilter = it },
                        onOpenArchived = { viewingArchived = true },
                        onStartAiChat = {
                            repository.getOrCreateAiChat { aiChatId ->
                                repository.markChatAsRead(aiChatId)
                                onNavigateToChat(aiChatId)
                            }
                        },
                        onChatClick = { chat ->
                            repository.markChatAsRead(chat.id)
                            onNavigateToChat(chat.id)
                        },
                        onChatLongClick = { chat ->
                            selectedChatForActions = chat
                        }
                    )
                }
                1 -> {
                    StatusTabContent(
                        currentUser = currentUser,
                        statuses = statuses,
                        onMyStatusClick = {
                            val myStatus = statuses.find { it.userId == currentUser?.uid }
                            if (myStatus != null && myStatus.items.isNotEmpty()) {
                                onNavigateToStatusViewer(myStatus.userId)
                            } else {
                                onNavigateToTextStatus()
                            }
                        },
                        onStatusClick = { userStatus ->
                            onNavigateToStatusViewer(userStatus.userId)
                        },
                        onAddStatus = onNavigateToTextStatus
                    )
                }
                2 -> {
                    CallsTabContent(
                        onStartCall = { name, isVideo ->
                            activeCallData = Triple(name, "", isVideo)
                        }
                    )
                }
                3 -> {
                    SettingsTabContent(
                        currentUser = currentUser,
                        onProfileClick = onNavigateToProfile,
                        onLogout = {
                            repository.logout()
                            onLogout()
                        }
                    )
                }
            }
        }
    }

    // Active Simulated Voice/Video Call Dialog
    activeCallData?.let { (callerName, callerPhoto, isVideo) ->
        ActiveCallDialog(
            callerName = callerName,
            callerPhoto = callerPhoto,
            isVideo = isVideo,
            onDismiss = { activeCallData = null }
        )
    }

    // Action Dialog for Long-press on Chat
    selectedChatForActions?.let { chat ->
        ChatActionDialog(
            chat = chat,
            onDismiss = { selectedChatForActions = null },
            onTogglePin = { repository.togglePinChat(chat.id) },
            onToggleArchive = { repository.toggleArchiveChat(chat.id) },
            onToggleMute = { repository.toggleMuteChat(chat.id) },
            onDelete = { repository.deleteChat(chat.id) }
        )
    }
}

@Composable
fun WhatsAppBottomNavigationBar(
    selectedTab: Int,
    unreadChatsCount: Int,
    hasUnseenStatus: Boolean,
    onTabSelected: (Int) -> Unit
) {
    Surface(
        color = WhatsAppSurface,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Column {
            HorizontalDivider(color = DividerColor, thickness = 1.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomNavItem(
                    label = "Chats",
                    icon = Icons.Default.Chat,
                    selected = selectedTab == 0,
                    badgeCount = unreadChatsCount,
                    onClick = { onTabSelected(0) },
                    testTag = "bottom_nav_chats"
                )
                BottomNavItem(
                    label = "Updates",
                    icon = Icons.Default.DonutLarge,
                    selected = selectedTab == 1,
                    hasDot = hasUnseenStatus,
                    onClick = { onTabSelected(1) },
                    testTag = "bottom_nav_updates"
                )
                BottomNavItem(
                    label = "Groups",
                    icon = Icons.Default.Groups,
                    selected = false,
                    onClick = { onTabSelected(4) },
                    testTag = "bottom_nav_groups"
                )
                BottomNavItem(
                    label = "Calls",
                    icon = Icons.Default.Phone,
                    selected = selectedTab == 2,
                    onClick = { onTabSelected(2) },
                    testTag = "bottom_nav_calls"
                )
                BottomNavItem(
                    label = "Settings",
                    icon = Icons.Default.Settings,
                    selected = selectedTab == 3,
                    onClick = { onTabSelected(3) },
                    testTag = "bottom_nav_settings"
                )
            }
        }
    }
}

@Composable
fun BottomNavItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    badgeCount: Int = 0,
    hasDot: Boolean = false,
    testTag: String = "",
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = if (selected) {
                    Modifier
                        .background(EmeraldContainer, RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                } else {
                    Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                }
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (selected) EmeraldPrimary else TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }
            if (badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .background(EmeraldPrimary, CircleShape)
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "$badgeCount",
                        color = DarkOnPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (hasDot) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(EmeraldLight, CircleShape)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) EmeraldPrimary else TextSecondary
        )
    }
}

@Composable
fun WhatsAppMainTopBar(
    selectedTab: Int,
    isSearchActive: Boolean,
    searchQuery: String,
    showMenu: Boolean,
    onSearchToggle: () -> Unit,
    onSearchChange: (String) -> Unit,
    onMenuToggle: () -> Unit,
    onMenuDismiss: () -> Unit,
    onCameraClick: () -> Unit,
    onNewGroup: () -> Unit,
    onProfileClick: () -> Unit,
    onLogout: () -> Unit
) {
    Surface(
        color = WhatsAppSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        if (isSearchActive) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Search chats, messages, groups...", color = TextMuted, fontSize = 14.sp) },
                    trailingIcon = {
                        IconButton(onClick = onSearchToggle) {
                            Icon(Icons.Default.Close, contentDescription = "Close Search", tint = TextSecondary)
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = DarkInputBackground,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = WhatsAppSurfaceVariant,
                        unfocusedContainerColor = WhatsAppSurfaceVariant
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("main_search_input")
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "واتساب الاسطورة محمد",
                        color = EmeraldPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(EmeraldContainer, RoundedCornerShape(4.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "👑 Alostora",
                            color = GoldAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCameraClick, modifier = Modifier.testTag("action_camera")) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Camera", tint = TextSecondary)
                    }

                    IconButton(onClick = onSearchToggle, modifier = Modifier.testTag("action_search")) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary)
                    }

                    Box {
                        IconButton(onClick = onMenuToggle, modifier = Modifier.testTag("action_menu")) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = TextSecondary)
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = onMenuDismiss,
                            modifier = Modifier.background(WhatsAppSurfaceVariant)
                        ) {
                            DropdownMenuItem(
                                text = { Text("New group", color = TextPrimary) },
                                leadingIcon = { Icon(Icons.Default.GroupAdd, contentDescription = null, tint = EmeraldPrimary) },
                                onClick = onNewGroup,
                                modifier = Modifier.testTag("menu_new_group")
                            )
                            DropdownMenuItem(
                                text = { Text("Profile & Bio", color = TextPrimary) },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary) },
                                onClick = onProfileClick,
                                modifier = Modifier.testTag("menu_profile")
                            )
                            DropdownMenuItem(
                                text = { Text("Starred messages", color = TextPrimary) },
                                leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = GoldAccent) },
                                onClick = onMenuDismiss
                            )
                            HorizontalDivider(color = DividerColor)
                            DropdownMenuItem(
                                text = { Text("Log out", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = onLogout,
                                modifier = Modifier.testTag("menu_logout")
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CallsTabContent(
    onStartCall: (String, Boolean) -> Unit
) {
    val callLogs = remember {
        listOf(
            CallLogItem("Alostora Mohamed 👑", "", true, CallType.INCOMING, "Today, 12:45 PM", true),
            CallLogItem("Maryam Al-Sayed", "", false, CallType.OUTGOING, "Today, 11:20 AM", true),
            CallLogItem("Alostora VIP Developers Club 🚀", "", false, CallType.INCOMING, "Yesterday, 8:15 PM", true),
            CallLogItem("Ahmed Tarek", "", false, CallType.MISSED, "Yesterday, 6:04 PM", false),
            CallLogItem("Sarah Smith", "", false, CallType.INCOMING, "October 24, 3:30 PM", true),
            CallLogItem("John Doe", "", false, CallType.OUTGOING, "October 22, 10:14 AM", true)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("calls_tab_content"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Create Call Link Card
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onStartCall("Alostora Call Room", true) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(EmeraldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Create call link",
                        tint = DarkOnPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Create call link",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Share a link for your WhatsApp call",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            Text(
                text = "Recent",
                color = TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        items(callLogs) { log ->
            CallLogItemRow(
                log = log,
                onAudioCall = { onStartCall(log.name, false) },
                onVideoCall = { onStartCall(log.name, true) }
            )
        }
    }
}

enum class CallType { INCOMING, OUTGOING, MISSED }

data class CallLogItem(
    val name: String,
    val photoUrl: String,
    val isVideo: Boolean,
    val type: CallType,
    val timestamp: String,
    val answered: Boolean
)

@Composable
fun CallLogItemRow(
    log: CallLogItem,
    onAudioCall: () -> Unit,
    onVideoCall: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { if (log.isVideo) onVideoCall() else onAudioCall() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        UserAvatar(
            photoUrl = log.photoUrl,
            displayName = log.name,
            size = 52.dp,
            isGroup = log.name.contains("Club") || log.name.contains("Group")
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = log.name,
                color = if (log.type == CallType.MISSED) Color(0xFFEF5350) else TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                when (log.type) {
                    CallType.INCOMING -> Icon(
                        imageVector = Icons.Default.CallReceived,
                        contentDescription = "Incoming",
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    CallType.OUTGOING -> Icon(
                        imageVector = Icons.Default.CallMade,
                        contentDescription = "Outgoing",
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    CallType.MISSED -> Icon(
                        imageVector = Icons.Default.CallMissed,
                        contentDescription = "Missed",
                        tint = Color(0xFFEF5350),
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = log.timestamp,
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        IconButton(onClick = if (log.isVideo) onVideoCall else onAudioCall) {
            Icon(
                imageVector = if (log.isVideo) Icons.Default.Videocam else Icons.Default.Call,
                contentDescription = if (log.isVideo) "Video call" else "Voice call",
                tint = EmeraldPrimary
            )
        }
    }
}

@Composable
fun ActiveCallDialog(
    callerName: String,
    callerPhoto: String,
    isVideo: Boolean,
    onDismiss: () -> Unit
) {
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var isCameraOff by remember { mutableStateOf(false) }
    var callSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            callSeconds++
        }
    }

    val callTimeFormatted = remember(callSeconds) {
        val mins = callSeconds / 60
        val secs = callSeconds % 60
        "%02d:%02d".format(mins, secs)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = WhatsAppBackground,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Info
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 40.dp)
                ) {
                    Text(
                        text = callerName,
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (callSeconds < 2) "Connecting..." else "WhatsApp ${if (isVideo) "Video" else "Audio"} Call • $callTimeFormatted",
                        color = EmeraldLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "🔒 End-to-end encrypted",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }

                // Center Avatar with pulsating green ring
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier
                            .size(170.dp)
                            .background(EmeraldContainer.copy(alpha = 0.5f), CircleShape)
                    )
                    UserAvatar(
                        photoUrl = callerPhoto,
                        displayName = callerName,
                        size = 140.dp
                    )
                }

                // Bottom Call Controls
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Speaker Button
                        IconButton(
                            onClick = { isSpeakerOn = !isSpeakerOn },
                            modifier = Modifier
                                .size(56.dp)
                                .background(if (isSpeakerOn) WhatsAppSurfaceVariant else EmeraldPrimary, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isSpeakerOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                                contentDescription = "Speaker",
                                tint = if (isSpeakerOn) TextPrimary else DarkOnPrimary
                            )
                        }

                        if (isVideo) {
                            // Video Camera Toggle
                            IconButton(
                                onClick = { isCameraOff = !isCameraOff },
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(if (isCameraOff) WhatsAppSurfaceVariant else EmeraldPrimary, CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isCameraOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                                    contentDescription = "Video",
                                    tint = if (isCameraOff) TextPrimary else DarkOnPrimary
                                )
                            }
                        }

                        // Mute Button
                        IconButton(
                            onClick = { isMuted = !isMuted },
                            modifier = Modifier
                                .size(56.dp)
                                .background(if (isMuted) Color(0xFFEF5350) else WhatsAppSurfaceVariant, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = TextPrimary
                            )
                        }
                    }

                    // End Call FAB
                    FloatingActionButton(
                        onClick = onDismiss,
                        containerColor = Color(0xFFE53935),
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(64.dp)
                            .testTag("btn_end_call")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "End Call",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatsTabContent(
    chats: List<Chat>,
    archivedCount: Int,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    activeFilter: String,
    onFilterSelect: (String) -> Unit,
    onOpenArchived: () -> Unit,
    onStartAiChat: () -> Unit,
    onChatClick: (Chat) -> Unit,
    onChatLongClick: (Chat) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Real-time Search Input Bar in Chats tab
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search chats, contacts, and subjects...", color = TextMuted, fontSize = 14.sp) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear search", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = EmeraldPrimary,
                unfocusedBorderColor = Color.Transparent,
                focusedContainerColor = WhatsAppSurfaceVariant,
                unfocusedContainerColor = WhatsAppSurfaceVariant,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("chats_realtime_search_bar")
        )

        // Quick filter chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = activeFilter == "all",
                onClick = { onFilterSelect("all") },
                label = { Text("All", fontSize = 13.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = TextPrimary,
                    containerColor = WhatsAppSurfaceVariant,
                    labelColor = TextSecondary
                ),
                border = null,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("filter_all")
            )
            FilterChip(
                selected = activeFilter == "unread",
                onClick = { onFilterSelect("unread") },
                label = { Text("Unread", fontSize = 13.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = TextPrimary,
                    containerColor = WhatsAppSurfaceVariant,
                    labelColor = TextSecondary
                ),
                border = null,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("filter_unread")
            )
            FilterChip(
                selected = activeFilter == "groups",
                onClick = { onFilterSelect("groups") },
                label = { Text("Groups", fontSize = 13.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = TextPrimary,
                    containerColor = WhatsAppSurfaceVariant,
                    labelColor = TextSecondary
                ),
                border = null,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("filter_groups")
            )
            FilterChip(
                selected = activeFilter == "ai",
                onClick = { onFilterSelect("ai") },
                leadingIcon = {
                    Icon(Icons.Default.SmartToy, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                },
                label = { Text("AI", fontSize = 13.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = TextPrimary,
                    containerColor = WhatsAppSurfaceVariant,
                    labelColor = TextSecondary
                ),
                border = null,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("filter_ai")
            )
        }

        // AI Assistant Quick Spotlight Card (when on all filter & not searching)
        if (activeFilter == "all" && searchQuery.isBlank()) {
            Card(
                onClick = onStartAiChat,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("card_ai_spotlight"),
                colors = CardDefaults.cardColors(containerColor = WhatsAppSurfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(EmeraldContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            tint = GoldAccent,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Alostora AI Assistant",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(EmeraldPrimary.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("AI 🤖", color = EmeraldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "Ask questions, draft messages & get instant AI replies",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open AI",
                        tint = EmeraldLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Archived Row (if archived chats exist)
        if (archivedCount > 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenArchived() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("row_archived_chats"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(WhatsAppSurfaceVariant, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Archive,
                        contentDescription = "Archived",
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Text(
                    text = "Archived",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "$archivedCount",
                    color = EmeraldLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            HorizontalDivider(color = DividerColor.copy(alpha = 0.3f), thickness = 0.5.dp, modifier = Modifier.padding(start = 72.dp))
        }

        if (chats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "No chats",
                        tint = TextMuted,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "No matching conversations" else "No conversations found",
                        color = TextSecondary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (searchQuery.isNotBlank()) "Try searching another contact name or group subject" else "Tap the green button to start a new chat or talk with AI Assistant",
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(chats, key = { it.id }) { chat ->
                    ChatItemRow(
                        chat = chat,
                        onClick = { onChatClick(chat) },
                        onLongClick = { onChatLongClick(chat) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatItemRow(
    chat: Chat,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("chat_item_${chat.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        UserAvatar(
            photoUrl = chat.photoUrl,
            displayName = chat.name,
            size = 54.dp,
            isGroup = chat.isGroup
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = chat.name,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = if (chat.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Text(
                    text = formatChatTime(chat.lastMessageTimestamp),
                    color = if (chat.unreadCount > 0) EmeraldLight else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = if (chat.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (chat.lastMessageSenderId.isNotEmpty() && !chat.isGroup) {
                        ReadReceiptIcon(
                            status = chat.lastMessageStatus,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }

                    val prefix = if (chat.isGroup && chat.lastMessageSenderName.isNotEmpty()) {
                        "${chat.lastMessageSenderName}: "
                    } else ""

                    Text(
                        text = "$prefix${chat.lastMessage.ifEmpty { "No messages yet" }}",
                        color = if (chat.unreadCount > 0) TextPrimary else TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (chat.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (chat.muted) {
                        Icon(
                            imageVector = Icons.Default.VolumeMute,
                            contentDescription = "Muted",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    if (chat.pinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = EmeraldLight,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    if (chat.unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .background(UnreadBadgeGreen, CircleShape)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${chat.unreadCount}",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArchivedChatsScreen(
    archivedChats: List<Chat>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onBack: () -> Unit,
    onChatClick: (Chat) -> Unit,
    onChatLongClick: (Chat) -> Unit
) {
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("archived_chats_screen"),
        containerColor = WhatsAppBackground,
        topBar = {
            Surface(color = WhatsAppSurface, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("btn_archived_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Archived chats",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${archivedChats.size} conversation${if (archivedChats.size == 1) "" else "s"}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Search inside archived
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search archived chats...", color = TextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = WhatsAppSurfaceVariant,
                    unfocusedContainerColor = WhatsAppSurfaceVariant,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            Text(
                text = "These chats stay archived when new messages are received.",
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            if (archivedChats.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Archive,
                            contentDescription = "No archived chats",
                            tint = TextMuted,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No archived conversations",
                            color = TextSecondary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Long-press any chat in your Chats list to archive it",
                            color = TextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(archivedChats, key = { it.id }) { chat ->
                        ChatItemRow(
                            chat = chat,
                            onClick = { onChatClick(chat) },
                            onLongClick = { onChatLongClick(chat) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatActionDialog(
    chat: Chat,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleArchive: () -> Unit,
    onToggleMute: () -> Unit,
    onDelete: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = WhatsAppSurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header with Chat Info
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(photoUrl = chat.photoUrl, displayName = chat.name, size = 48.dp, isGroup = chat.isGroup)
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = chat.name,
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (chat.isGroup) "Group conversation" else "Direct chat",
                            color = EmeraldLight,
                            fontSize = 12.sp
                        )
                    }
                }

                HorizontalDivider(color = DividerColor.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 14.dp))

                // Actions List
                // 1. Pin / Unpin
                ChatActionOptionRow(
                    icon = Icons.Default.PushPin,
                    title = if (chat.pinned) "Unpin chat (إلغاء التثبيت)" else "Pin to top (تثبيت في الأعلى)",
                    onClick = {
                        onTogglePin()
                        onDismiss()
                    }
                )

                // 2. Archive / Unarchive
                ChatActionOptionRow(
                    icon = if (chat.archived) Icons.Default.Unarchive else Icons.Default.Archive,
                    title = if (chat.archived) "Unarchive chat (إلغاء الأرشفة)" else "Archive chat (أرشفة المحادثة)",
                    onClick = {
                        onToggleArchive()
                        onDismiss()
                    }
                )

                // 3. Mute / Unmute
                ChatActionOptionRow(
                    icon = if (chat.muted) Icons.AutoMirrored.Filled.VolumeUp else Icons.Default.VolumeMute,
                    title = if (chat.muted) "Unmute notifications (إلغاء الكتم)" else "Mute notifications (كتم الإشعارات)",
                    onClick = {
                        onToggleMute()
                        onDismiss()
                    }
                )

                // 4. Delete
                ChatActionOptionRow(
                    icon = Icons.Default.Delete,
                    title = "Delete conversation (حذف المحادثة)",
                    iconTint = Color(0xFFEF5350),
                    textColor = Color(0xFFEF5350),
                    onClick = {
                        onDelete()
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ChatActionOptionRow(
    icon: ImageVector,
    title: String,
    iconTint: Color = TextPrimary,
    textColor: Color = TextPrimary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = iconTint, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = title, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun StatusTabContent(
    currentUser: com.example.data.models.User?,
    statuses: List<UserStatusGroup>,
    onMyStatusClick: () -> Unit,
    onStatusClick: (UserStatusGroup) -> Unit,
    onAddStatus: () -> Unit
) {
    val myStatusGroup = statuses.find { it.userId == currentUser?.uid }
    val otherStatuses = statuses.filter { it.userId != currentUser?.uid }
    val recentStatuses = otherStatuses.filter { it.hasUnseen }
    val viewedStatuses = otherStatuses.filter { !it.hasUnseen }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("status_tab_content"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
    ) {
        // My Status Row
        item {
            Text(
                text = "Status",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onMyStatusClick() }
                    .padding(vertical = 6.dp)
                    .testTag("my_status_item"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(contentAlignment = Alignment.BottomEnd) {
                    UserAvatar(
                        photoUrl = currentUser?.photoUrl ?: "",
                        displayName = currentUser?.displayName ?: "Me",
                        size = 54.dp
                    )
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .background(EmeraldPrimary, CircleShape)
                            .clickable { onAddStatus() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add status",
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "My Status",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (myStatusGroup != null && myStatusGroup.items.isNotEmpty()) {
                            "${myStatusGroup.items.size} updates • Tap to view"
                        } else {
                            "Tap to add status update"
                        },
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            HorizontalDivider(
                color = DividerColor,
                modifier = Modifier.padding(vertical = 14.dp)
            )
        }

        // Recent Updates
        if (recentStatuses.isNotEmpty()) {
            item {
                Text(
                    text = "Recent updates",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }
            items(recentStatuses, key = { it.userId }) { group ->
                StatusGroupItemRow(group = group, onClick = { onStatusClick(group) })
            }
        }

        // Viewed Updates
        if (viewedStatuses.isNotEmpty()) {
            item {
                Text(
                    text = "Viewed updates",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 10.dp)
                )
            }
            items(viewedStatuses, key = { it.userId }) { group ->
                StatusGroupItemRow(group = group, onClick = { onStatusClick(group) })
            }
        }
    }
}

@Composable
fun StatusGroupItemRow(
    group: UserStatusGroup,
    onClick: () -> Unit
) {
    val lastItem = group.items.lastOrNull()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp)
            .testTag("status_group_${group.userId}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusRingAvatar(
            photoUrl = group.userPhotoUrl,
            displayName = group.userName,
            itemCount = group.items.size,
            hasUnseen = group.hasUnseen,
            size = 56.dp,
            onClick = onClick
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = group.userName,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = if (lastItem != null) formatChatTime(lastItem.timestamp) else "Today",
                color = TextSecondary,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun SettingsTabContent(
    currentUser: com.example.data.models.User?,
    onProfileClick: () -> Unit,
    onLogout: () -> Unit
) {
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showChatsDialog by remember { mutableStateOf(false) }
    var showNotificationsDialog by remember { mutableStateOf(false) }
    var showStorageDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    // Privacy States
    var readReceiptsEnabled by remember { mutableStateOf(true) }
    var lastSeenOption by remember { mutableStateOf("Everyone") }
    var profilePhotoOption by remember { mutableStateOf("Everyone") }

    // Chat States
    var enterIsSend by remember { mutableStateOf(true) }
    var mediaVisibility by remember { mutableStateOf(true) }
    var chatTheme by remember { mutableStateOf("Dark (Alostora Emerald)") }

    // Notification States
    var conversationTones by remember { mutableStateOf(true) }
    var highPriorityNotifs by remember { mutableStateOf(true) }
    var reactionNotifs by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_tab_content"),
        contentPadding = PaddingValues(bottom = 40.dp)
    ) {
        // User Profile Header Card
        item {
            Card(
                shape = RoundedCornerShape(0.dp),
                colors = CardDefaults.cardColors(containerColor = WhatsAppSurfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProfileClick() }
                    .testTag("settings_profile_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(
                        photoUrl = currentUser?.photoUrl ?: "",
                        displayName = currentUser?.displayName ?: "User",
                        size = 64.dp
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentUser?.displayName ?: "Mohamed Alostora 👑",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = currentUser?.about ?: "Living the Legend 👑",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentUser?.phoneNumber ?: "+20 100 000 0000",
                            color = TextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    IconButton(onClick = onProfileClick) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "QR Code",
                            tint = EmeraldPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }

        // Settings items
        item {
            SettingsMenuItem(
                icon = Icons.Default.Person,
                title = "Account",
                subtitle = "Security notifications, change number",
                onClick = onProfileClick
            )
            SettingsMenuItem(
                icon = Icons.Default.Lock,
                title = "Privacy",
                subtitle = "Block contacts, read receipts, last seen",
                onClick = { showPrivacyDialog = true },
                testTag = "settings_privacy_item"
            )
            SettingsMenuItem(
                icon = Icons.Default.Chat,
                title = "Chats",
                subtitle = "Theme, wallpapers, chat history",
                onClick = { showChatsDialog = true },
                testTag = "settings_chats_item"
            )
            SettingsMenuItem(
                icon = Icons.Default.Notifications,
                title = "Notifications",
                subtitle = "Message, group & call tones",
                onClick = { showNotificationsDialog = true },
                testTag = "settings_notifications_item"
            )
            SettingsMenuItem(
                icon = Icons.Default.Storage,
                title = "Storage and data",
                subtitle = "Network usage, auto-download",
                onClick = { showStorageDialog = true },
                testTag = "settings_storage_item"
            )
            SettingsMenuItem(
                icon = Icons.Default.HelpOutline,
                title = "Help",
                subtitle = "Help center, contact us, privacy policy",
                onClick = { showHelpDialog = true },
                testTag = "settings_help_item"
            )

            HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 8.dp))

            // App info section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "Alostora badge",
                    tint = GoldAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("WhatsApp Alostora Mohamed 2026", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Powered by Cloud Firestore & Jetpack Compose 👑", color = TextSecondary, fontSize = 12.sp)
                }
            }

            SettingsMenuItem(
                icon = Icons.AutoMirrored.Filled.ExitToApp,
                title = "Log out",
                subtitle = "Sign out of this device",
                tint = MaterialTheme.colorScheme.error,
                onClick = onLogout,
                testTag = "settings_logout_button"
            )
        }
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Settings", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Read Receipts", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text("If turned off, you won't send or receive Read receipts.", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = readReceiptsEnabled,
                            onCheckedChange = { readReceiptsEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = EmeraldPrimary
                            )
                        )
                    }
                    HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 4.dp))
                    Text("Who can see my personal info", color = EmeraldLight, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    Text("Last Seen & Online: $lastSeenOption", color = TextPrimary, fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
                    Text("Profile Photo: $profilePhotoOption", color = TextPrimary, fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
                    Text("Disappearing messages: Off", color = TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("Done", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }

    // Chats Dialog
    if (showChatsDialog) {
        AlertDialog(
            onDismissRequest = { showChatsDialog = false },
            title = { Text("Chats Settings", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enter is send", color = TextPrimary, fontSize = 15.sp)
                            Text("Enter key will send your message", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = enterIsSend,
                            onCheckedChange = { enterIsSend = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Media visibility", color = TextPrimary, fontSize = 15.sp)
                            Text("Show newly downloaded media in your gallery", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = mediaVisibility,
                            onCheckedChange = { mediaVisibility = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
                        )
                    }
                    HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 6.dp))
                    Text("Current Theme: $chatTheme", color = EmeraldLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Wallpaper: Default WhatsApp Alostora Dark Emerald", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = { showChatsDialog = false }) {
                    Text("Done", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }

    // Notifications Dialog
    if (showNotificationsDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationsDialog = false },
            title = { Text("Notifications Settings", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Conversation tones", color = TextPrimary, fontSize = 15.sp)
                            Text("Play sounds for incoming and outgoing messages", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = conversationTones,
                            onCheckedChange = { conversationTones = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("High priority notifications", color = TextPrimary, fontSize = 15.sp)
                            Text("Show previews of notifications at the top of the screen", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = highPriorityNotifs,
                            onCheckedChange = { highPriorityNotifs = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Reaction notifications", color = TextPrimary, fontSize = 15.sp)
                            Text("Show notifications for reactions to messages you send", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = reactionNotifs,
                            onCheckedChange = { reactionNotifs = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = EmeraldPrimary)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotificationsDialog = false }) {
                    Text("Done", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }

    // Storage Dialog
    if (showStorageDialog) {
        AlertDialog(
            onDismissRequest = { showStorageDialog = false },
            title = { Text("Storage and Data", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Manage Storage", color = EmeraldLight, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Used: 1.2 GB • Free: 28.4 GB", color = TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(vertical = 2.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .background(DividerColor, RoundedCornerShape(3.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.25f)
                                .height(6.dp)
                                .background(EmeraldPrimary, RoundedCornerShape(3.dp))
                        )
                    }
                    HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 8.dp))
                    Text("Network Usage", color = EmeraldLight, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Sent: 420.5 MB • Received: 890.2 MB", color = TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(vertical = 2.dp))
                    Text("Media Auto-download: Wi-Fi only (Photos, Audio, Videos)", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = { showStorageDialog = false }) {
                    Text("Done", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }

    // Help Dialog
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("WhatsApp Alostora Help", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("WhatsApp Alostora Mohamed 👑", color = EmeraldLight, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Version 2026.4.12 Pro Edition", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    Text("• End-to-end encrypted messaging\n• High definition voice and video calling\n• Real-time Firebase Firestore synchronization\n• Alostora AI Assistant Smart Replies\n• Status stories & group collaboration", color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text("Close", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }
}

@Composable
fun SettingsMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color = TextSecondary,
    testTag: String = "",
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = tint,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(20.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = if (tint == MaterialTheme.colorScheme.error) tint else TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            if (subtitle.isNotEmpty()) {
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
        )
    }
}
