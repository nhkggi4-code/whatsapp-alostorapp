package com.example.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.repository.ChatRepository
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.group.CreateGroupScreen
import com.example.ui.screens.group.GroupInfoScreen
import com.example.ui.screens.main.MainScreen
import com.example.ui.screens.settings.ProfileEditScreen
import com.example.ui.screens.status.StatusViewerScreen
import com.example.ui.screens.status.TextStatusComposerScreen

object Routes {
    const val AUTH = "auth"
    const val MAIN = "main"
    const val CHAT = "chat/{chatId}"
    const val CREATE_GROUP = "create_group"
    const val GROUP_INFO = "group_info/{chatId}"
    const val STATUS_VIEWER = "status_viewer/{userId}"
    const val TEXT_STATUS = "text_status"
    const val PROFILE = "profile"

    fun chat(chatId: String) = "chat/$chatId"
    fun groupInfo(chatId: String) = "group_info/$chatId"
    fun statusViewer(userId: String) = "status_viewer/$userId"
}

@Composable
fun AppNavigation(
    repository: ChatRepository,
    navController: NavHostController = rememberNavController()
) {
    val currentUser by repository.currentUser.collectAsState()
    val startDestination = if (currentUser != null) Routes.MAIN else Routes.AUTH

    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            slideIntoContainer(
                AnimatedContentTransitionScope.SlideDirection.Left,
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        exitTransition = {
            slideOutOfContainer(
                AnimatedContentTransitionScope.SlideDirection.Left,
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        },
        popEnterTransition = {
            slideIntoContainer(
                AnimatedContentTransitionScope.SlideDirection.Right,
                animationSpec = tween(300)
            ) + fadeIn(animationSpec = tween(300))
        },
        popExitTransition = {
            slideOutOfContainer(
                AnimatedContentTransitionScope.SlideDirection.Right,
                animationSpec = tween(300)
            ) + fadeOut(animationSpec = tween(300))
        }
    ) {
        // Authentication Screen
        composable(Routes.AUTH) {
            AuthScreen(
                repository = repository,
                onAuthSuccess = {
                    navController.navigate(Routes.MAIN) {
                        popUpTo(Routes.AUTH) { inclusive = true }
                    }
                }
            )
        }

        // Main Tabbed Screen (Chats, Status, Settings)
        composable(Routes.MAIN) {
            MainScreen(
                repository = repository,
                onNavigateToChat = { chatId ->
                    navController.navigate(Routes.chat(chatId))
                },
                onNavigateToCreateGroup = {
                    navController.navigate(Routes.CREATE_GROUP)
                },
                onNavigateToStatusViewer = { userId ->
                    navController.navigate(Routes.statusViewer(userId))
                },
                onNavigateToTextStatus = {
                    navController.navigate(Routes.TEXT_STATUS)
                },
                onNavigateToProfile = {
                    navController.navigate(Routes.PROFILE)
                },
                onLogout = {
                    navController.navigate(Routes.AUTH) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        // Chat Screen
        composable(
            route = Routes.CHAT,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
            ChatScreen(
                chatId = chatId,
                repository = repository,
                onBack = { navController.popBackStack() },
                onNavigateToGroupInfo = { gid ->
                    navController.navigate(Routes.groupInfo(gid))
                }
            )
        }

        // Create Group Screen
        composable(Routes.CREATE_GROUP) {
            CreateGroupScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onGroupCreated = { newChatId ->
                    navController.popBackStack()
                    navController.navigate(Routes.chat(newChatId))
                }
            )
        }

        // Group Info Screen
        composable(
            route = Routes.GROUP_INFO,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
            GroupInfoScreen(
                chatId = chatId,
                repository = repository,
                onBack = { navController.popBackStack() },
                onExitGroupSuccess = {
                    navController.popBackStack(Routes.MAIN, inclusive = false)
                }
            )
        }

        // Status Story Viewer Screen
        composable(
            route = Routes.STATUS_VIEWER,
            arguments = listOf(navArgument("userId") { type = NavType.StringType })
        ) { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            StatusViewerScreen(
                userId = userId,
                repository = repository,
                onClose = { navController.popBackStack() },
                onNavigateToChatWithUser = { uid ->
                    navController.popBackStack()
                }
            )
        }

        // Text / Media Status Composer Screen
        composable(Routes.TEXT_STATUS) {
            TextStatusComposerScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onPosted = { navController.popBackStack() }
            )
        }

        // Profile & Bio Edit Screen
        composable(Routes.PROFILE) {
            ProfileEditScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
