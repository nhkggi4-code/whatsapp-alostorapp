package com.example.ui.screens.chat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.models.Chat
import com.example.data.models.Message
import com.example.data.models.MessageStatus
import com.example.data.models.MessageType
import com.example.data.repository.ChatRepository
import com.example.ui.components.ActiveCallDialog
import com.example.ui.components.DateHeaderPill
import com.example.ui.components.EmojiStickerSheet
import com.example.ui.components.ReadReceiptIcon
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatDetailTimestamp
import com.example.ui.components.formatMessageTime
import com.example.ui.theme.BubbleDirectReply
import com.example.ui.theme.BubbleReceived
import com.example.ui.theme.BubbleSent
import com.example.ui.theme.DarkInputBackground
import com.example.ui.theme.DividerColor
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ReadTickBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhatsAppBackground
import com.example.ui.theme.WhatsAppSurface
import com.example.ui.theme.WhatsAppSurfaceContainer
import com.example.ui.theme.WhatsAppSurfaceVariant
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chatId: String,
    repository: ChatRepository,
    onBack: () -> Unit,
    onNavigateToGroupInfo: (String) -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val chats by repository.chats.collectAsState()
    val chat = remember(chats, chatId) { chats.find { it.id == chatId } }

    val messagesFlow = remember(chatId) { repository.getMessagesFlow(chatId) }
    val messages by messagesFlow.collectAsState()

    val typingMap by repository.typingStatus.collectAsState()
    val remoteTypingUsers = remember(typingMap, chatId, currentUser) {
        (typingMap[chatId] ?: emptyList()).filter { it != currentUser?.displayName && it != currentUser?.uid }
    }
    val isRemoteTyping = remoteTypingUsers.isNotEmpty()
    val remoteTypingText = remember(remoteTypingUsers) {
        when {
            remoteTypingUsers.isEmpty() -> ""
            remoteTypingUsers.size == 1 -> "${remoteTypingUsers.first()} is typing..."
            else -> "${remoteTypingUsers.joinToString(", ")} are typing..."
        }
    }

    var inputText by remember { mutableStateOf("") }
    var replyingTo by remember { mutableStateOf<Message?>(null) }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var showEmojiSheet by remember { mutableStateOf(false) }
    var showOptionsMenu by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }
    var selectedImageForPreview by remember { mutableStateOf<String?>(null) }
    var showCallDialog by remember { mutableStateOf<String?>(null) } // "Voice" or "Video"
    var showReactionMenuForMessage by remember { mutableStateOf<Message?>(null) }
    var showMessageInfoForMessage by remember { mutableStateOf<Message?>(null) }
    var isSearching by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Mark messages as seen in Firestore in real-time when entering chat or when messages arrive
    LaunchedEffect(chatId, messages.size) {
        repository.markMessagesAsSeen(chatId)
    }

    val filteredMessages = remember(messages, searchQuery) {
        if (searchQuery.isBlank()) messages
        else messages.filter { it.text.contains(searchQuery, ignoreCase = true) || it.mediaFileName.contains(searchQuery, ignoreCase = true) }
    }

    // Real-time typing publisher in Firestore
    LaunchedEffect(inputText) {
        if (inputText.isNotBlank()) {
            repository.setTyping(chatId, isTyping = true)
            kotlinx.coroutines.delay(3000)
            repository.setTyping(chatId, isTyping = false)
        } else {
            repository.setTyping(chatId, isTyping = false)
        }
    }

    DisposableEffect(chatId) {
        onDispose {
            repository.setTyping(chatId, isTyping = false)
        }
    }

    // Scroll to bottom when messages update or remote user starts typing
    LaunchedEffect(messages.size, isRemoteTyping) {
        if (messages.isNotEmpty() || isRemoteTyping) {
            val targetIdx = if (isRemoteTyping) messages.size else (messages.size - 1).coerceAtLeast(0)
            listState.animateScrollToItem(targetIdx)
        }
    }

    // Media Pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            repository.sendMessage(
                chatId = chatId,
                text = inputText,
                type = MessageType.IMAGE,
                mediaUri = uri,
                mediaFileName = "photo_${System.currentTimeMillis()}.jpg",
                replyTo = replyingTo
            )
            inputText = ""
            replyingTo = null
            showAttachmentSheet = false
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            repository.sendMessage(
                chatId = chatId,
                text = inputText,
                type = MessageType.DOCUMENT,
                mediaUri = uri,
                mediaFileName = "Document_${System.currentTimeMillis().toString().takeLast(4)}.pdf",
                replyTo = replyingTo
            )
            inputText = ""
            replyingTo = null
            showAttachmentSheet = false
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            repository.sendMessage(
                chatId = chatId,
                text = inputText,
                type = MessageType.AUDIO,
                mediaUri = uri,
                mediaFileName = "VoiceNote_${System.currentTimeMillis().toString().takeLast(4)}.mp3",
                replyTo = replyingTo
            )
            inputText = ""
            replyingTo = null
            showAttachmentSheet = false
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chat_screen_$chatId"),
        containerColor = WhatsAppBackground,
        topBar = {
            ChatTopAppBar(
                chat = chat,
                isSearching = isSearching,
                searchQuery = searchQuery,
                onSearchQueryChange = { searchQuery = it },
                onSearchClose = {
                    isSearching = false
                    searchQuery = ""
                },
                onStartSearch = { isSearching = true },
                isRemoteTyping = isRemoteTyping,
                remoteTypingText = remoteTypingText,
                onBack = onBack,
                onHeaderClick = {
                    if (chat?.isGroup == true) {
                        onNavigateToGroupInfo(chatId)
                    }
                },
                onVoiceCall = { showCallDialog = "Voice" },
                onVideoCall = { showCallDialog = "Video" },
                showMenu = showOptionsMenu,
                onMenuToggle = { showOptionsMenu = !showOptionsMenu },
                onMenuDismiss = { showOptionsMenu = false },
                onWallpaperClick = {
                    showOptionsMenu = false
                    showWallpaperDialog = true
                },
                onGroupInfo = {
                    showOptionsMenu = false
                    if (chat?.isGroup == true) onNavigateToGroupInfo(chatId)
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            // Messages List with custom aesthetic background
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Background Wallpaper Canvas
                ChatWallpaperCanvas(wallpaper = chat?.wallpaper ?: "default")

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp)
                ) {
                    // Date pill at start
                    item {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            DateHeaderPill(timestamp = filteredMessages.firstOrNull()?.timestamp ?: System.currentTimeMillis())
                        }
                    }

                    items(filteredMessages, key = { it.id }) { message ->
                        val isSentByMe = message.senderId == currentUser?.uid
                        MessageBubble(
                            message = message,
                            isSentByMe = isSentByMe,
                            isGroup = chat?.isGroup == true,
                            onImageClick = { url -> selectedImageForPreview = url },
                            onLongClick = { showReactionMenuForMessage = message },
                            onReactionClick = { emoji ->
                                repository.toggleReaction(chatId, message.id, emoji)
                            }
                        )
                    }

                    // Real-time typing bubble in chat stream
                    if (isRemoteTyping) {
                        item {
                            TypingIndicatorBubble(
                                name = if (chat?.isGroup == true) remoteTypingUsers.joinToString(", ") else null
                            )
                        }
                    }
                }
            }

            // Replying Banner
            AnimatedVisibility(
                visible = replyingTo != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                val rep = replyingTo
                if (rep != null) {
                    Surface(
                        color = WhatsAppSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(36.dp)
                                    .background(EmeraldPrimary, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = rep.senderName,
                                    color = EmeraldLight,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = rep.text.ifEmpty { "Attachment" },
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { replyingTo = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel reply", tint = TextSecondary)
                            }
                        }
                    }
                }
            }

            // Emoji / Sticker Sheet
            if (showEmojiSheet) {
                EmojiStickerSheet(
                    onEmojiSelected = { emoji ->
                        inputText += emoji
                    },
                    onStickerSelected = { sticker ->
                        repository.sendMessage(
                            chatId = chatId,
                            text = sticker,
                            type = MessageType.TEXT,
                            replyTo = replyingTo
                        )
                        replyingTo = null
                        showEmojiSheet = false
                    },
                    onDismiss = { showEmojiSheet = false }
                )
            }

            // Bottom Input Bar
            ChatInputBar(
                text = inputText,
                onTextChange = { inputText = it },
                onEmojiClick = { showEmojiSheet = !showEmojiSheet },
                onSend = {
                    if (inputText.isNotBlank()) {
                        repository.sendMessage(
                            chatId = chatId,
                            text = inputText.trim(),
                            type = MessageType.TEXT,
                            replyTo = replyingTo
                        )
                        inputText = ""
                        replyingTo = null
                    }
                },
                onAttachClick = { showAttachmentSheet = true },
                onCameraClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onVoiceRecord = {
                    // Send a fast high-quality audio voice note simulator
                    repository.sendMessage(
                        chatId = chatId,
                        text = "Voice message (0:14)",
                        type = MessageType.AUDIO,
                        mediaFileName = "voice_alostora_${System.currentTimeMillis().toString().takeLast(4)}.m4a",
                        replyTo = replyingTo
                    )
                    replyingTo = null
                }
            )
        }
    }

    // Attachment Modal Bottom Sheet
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            sheetState = rememberModalBottomSheetState(),
            containerColor = WhatsAppSurfaceVariant,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "Share Content to Chat",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    AttachmentOptionItem(
                        icon = Icons.Default.Image,
                        label = "Gallery",
                        backgroundColor = Color(0xFFAC44CF),
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                    AttachmentOptionItem(
                        icon = Icons.Default.CameraAlt,
                        label = "Camera",
                        backgroundColor = Color(0xFFD3396D),
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                    AttachmentOptionItem(
                        icon = Icons.AutoMirrored.Filled.InsertDriveFile,
                        label = "Document",
                        backgroundColor = Color(0xFF5F66CD),
                        onClick = { documentPickerLauncher.launch("*/*") }
                    )
                    AttachmentOptionItem(
                        icon = Icons.Default.Audiotrack,
                        label = "Audio",
                        backgroundColor = Color(0xFFE07A26),
                        onClick = { audioPickerLauncher.launch("audio/*") }
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Reaction Popup Menu Dialog
    if (showReactionMenuForMessage != null) {
        val targetMsg = showReactionMenuForMessage!!
        Dialog(onDismissRequest = { showReactionMenuForMessage = null }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = WhatsAppSurfaceContainer,
                shadowElevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "React to message",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val emojis = listOf("❤️", "👍", "🔥", "😂", "😮", "👏", "👑")
                        emojis.forEach { emoji ->
                            Text(
                                text = emoji,
                                fontSize = 26.sp,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable {
                                        repository.toggleReaction(chatId, targetMsg.id, emoji)
                                        showReactionMenuForMessage = null
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                showMessageInfoForMessage = targetMsg
                                showReactionMenuForMessage = null
                            }
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "Info", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Info", color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                replyingTo = targetMsg
                                showReactionMenuForMessage = null
                            }
                        ) {
                            Text("Reply", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Message Info Dialog for Read Receipts & Delivery Details
    if (showMessageInfoForMessage != null) {
        MessageInfoDialog(
            message = showMessageInfoForMessage!!,
            chat = chat,
            currentUser = currentUser,
            onDismiss = { showMessageInfoForMessage = null }
        )
    }

    // Wallpaper Selection Dialog
    if (showWallpaperDialog) {
        WallpaperSelectionDialog(
            currentWallpaper = chat?.wallpaper ?: "default",
            onSelectWallpaper = { selectedKey ->
                repository.setChatWallpaper(chatId, selectedKey)
            },
            onDismiss = { showWallpaperDialog = false }
        )
    }

    // Call Dialog
    if (showCallDialog != null) {
        ActiveCallDialog(
            callerName = chat?.name ?: "Chat",
            callerPhoto = chat?.photoUrl ?: "",
            isVideo = showCallDialog == "Video",
            onDismiss = { showCallDialog = null }
        )
    }

    // Image Fullscreen Preview Dialog
    if (selectedImageForPreview != null) {
        Dialog(onDismissRequest = { selectedImageForPreview = null }) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable { selectedImageForPreview = null },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(selectedImageForPreview)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Full Preview",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
}

@Composable
fun ChatTopAppBar(
    chat: Chat?,
    isSearching: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onSearchClose: () -> Unit,
    onStartSearch: () -> Unit,
    isRemoteTyping: Boolean = false,
    remoteTypingText: String = "",
    onBack: () -> Unit,
    onHeaderClick: () -> Unit,
    onVoiceCall: () -> Unit,
    onVideoCall: () -> Unit,
    showMenu: Boolean,
    onMenuToggle: () -> Unit,
    onMenuDismiss: () -> Unit,
    onWallpaperClick: () -> Unit,
    onGroupInfo: () -> Unit
) {
    Surface(
        color = WhatsAppSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        if (isSearching) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onSearchClose) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Close search",
                        tint = TextPrimary
                    )
                }

                BasicTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("chat_search_field"),
                    textStyle = TextStyle(color = TextPrimary, fontSize = 16.sp),
                    cursorBrush = SolidColor(EmeraldPrimary),
                    decorationBox = { innerTextField ->
                        if (searchQuery.isEmpty()) {
                            Text("Search in chat...", color = TextMuted, fontSize = 16.sp)
                        }
                        innerTextField()
                    }
                )

                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onHeaderClick() }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(
                        photoUrl = chat?.photoUrl ?: "",
                        displayName = chat?.name ?: "Chat",
                        size = 40.dp,
                        isGroup = chat?.isGroup == true,
                        isOnline = true,
                        showOnlineIndicator = chat?.isGroup != true
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = chat?.name ?: "Loading...",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (isRemoteTyping) {
                            Text(
                                text = remoteTypingText.ifEmpty { "typing..." },
                                color = EmeraldLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            Text(
                                text = if (chat?.isGroup == true) {
                                    "${chat.participantIds.size} participants"
                                } else {
                                    "online"
                                },
                                color = if (chat?.isGroup == true) TextSecondary else EmeraldLight,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                IconButton(onClick = onVideoCall, modifier = Modifier.testTag("chat_action_video_call")) {
                    Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = TextPrimary)
                }

                IconButton(onClick = onVoiceCall, modifier = Modifier.testTag("chat_action_voice_call")) {
                    Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = TextPrimary)
                }

                Box {
                    IconButton(onClick = onMenuToggle, modifier = Modifier.testTag("chat_action_menu")) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = onMenuDismiss,
                        modifier = Modifier.background(WhatsAppSurfaceVariant)
                    ) {
                        if (chat?.isGroup == true) {
                            DropdownMenuItem(
                                text = { Text("Group info", color = TextPrimary) },
                                onClick = onGroupInfo,
                                modifier = Modifier.testTag("menu_group_info")
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Search", color = TextPrimary) },
                            onClick = {
                                onMenuDismiss()
                                onStartSearch()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Wallpaper (خلفية الدردشة)", color = TextPrimary) },
                            onClick = onWallpaperClick,
                            leadingIcon = {
                                Icon(Icons.Default.Wallpaper, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                            },
                            modifier = Modifier.testTag("menu_chat_wallpaper")
                        )
                        DropdownMenuItem(
                            text = { Text("Media, links, and docs", color = TextPrimary) },
                            onClick = onMenuDismiss
                        )
                        DropdownMenuItem(
                            text = { Text("Mute notifications", color = TextPrimary) },
                            onClick = onMenuDismiss
                        )
                        DropdownMenuItem(
                            text = { Text("Clear chat", color = TextPrimary) },
                            onClick = onMenuDismiss
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatWallpaperCanvas(wallpaper: String) {
    when (wallpaper) {
        "emerald_lush" -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF00382B),
                                Color(0xFF04201A),
                                Color(0xFF0B141A)
                            )
                        )
                    )
            )
        }
        "emerald_aurora" -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF005B48),
                                Color(0xFF00382E),
                                Color(0xFF0B141A)
                            ),
                            start = Offset(0f, 0f),
                            end = Offset(1000f, 1600f)
                        )
                    )
            )
        }
        "royal_gold_emerald" -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0E382B),
                                Color(0xFF1E2812),
                                Color(0xFF0B141A)
                            )
                        )
                    )
            )
        }
        "midnight_obsidian" -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF192231),
                                Color(0xFF0F172A),
                                Color(0xFF030712)
                            )
                        )
                    )
            )
        }
        "geometric_abstract" -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF09171C))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val spacing = 48.dp.toPx()
                    val dotRadius = 1.5.dp.toPx()
                    val emeraldTint = Color(0xFF00A884).copy(alpha = 0.12f)

                    for (x in 0..(size.width / spacing).toInt() + 1) {
                        for (y in 0..(size.height / spacing).toInt() + 1) {
                            drawCircle(
                                color = emeraldTint,
                                radius = dotRadius,
                                center = Offset(x * spacing, y * spacing)
                            )
                            if ((x + y) % 2 == 0) {
                                drawLine(
                                    color = emeraldTint.copy(alpha = 0.05f),
                                    start = Offset(x * spacing, y * spacing),
                                    end = Offset((x + 1) * spacing, (y + 1) * spacing),
                                    strokeWidth = 1f
                                )
                            }
                        }
                    }
                }
            }
        }
        else -> {
            // Default WhatsApp dark background
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(WhatsAppBackground)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val dotRadius = 1.dp.toPx()
                    val spacing = 36.dp.toPx()
                    val subtleDot = Color(0xFF1E2F38).copy(alpha = 0.4f)
                    for (x in 0..(size.width / spacing).toInt() + 1) {
                        for (y in 0..(size.height / spacing).toInt() + 1) {
                            drawCircle(
                                color = subtleDot,
                                radius = dotRadius,
                                center = Offset(x * spacing + if (y % 2 == 0) 18.dp.toPx() else 0f, y * spacing)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TypingIndicatorBubble(name: String? = null) {
    val infiniteTransition = rememberInfiniteTransition(label = "typing_dots")
    val dot1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot1"
    )
    val dot2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, delayMillis = 150, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot2"
    )
    val dot3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, delayMillis = 300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot3"
    )

    Row(
        modifier = Modifier
            .padding(vertical = 4.dp, horizontal = 4.dp)
            .testTag("typing_indicator_bubble"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = WhatsAppSurfaceVariant,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (!name.isNullOrBlank()) {
                    Text(
                        text = "$name is typing",
                        color = EmeraldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .padding(top = (dot1 + 6).dp)
                        .background(EmeraldPrimary, CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .padding(top = (dot2 + 6).dp)
                        .background(EmeraldPrimary, CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .padding(top = (dot3 + 6).dp)
                        .background(EmeraldPrimary, CircleShape)
                )
            }
        }
    }
}

@Composable
fun WallpaperSelectionDialog(
    currentWallpaper: String,
    onSelectWallpaper: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val wallpapers = listOf(
        Triple("default", "Classic Emerald Dark (الافتراضي)", listOf(Color(0xFF0B141A), Color(0xFF121B22))),
        Triple("emerald_lush", "Lush Forest Gradient (غابة الزمرد)", listOf(Color(0xFF00382B), Color(0xFF0B141A))),
        Triple("emerald_aurora", "Teal Aurora Glow (الشفق الأخضر)", listOf(Color(0xFF005B48), Color(0xFF00382E))),
        Triple("royal_gold_emerald", "Alostora Royal Gold (الأسطورة الملكي)", listOf(Color(0xFF0E382B), Color(0xFF282208))),
        Triple("midnight_obsidian", "Midnight Obsidian (سماء منتصف الليل)", listOf(Color(0xFF192231), Color(0xFF030712))),
        Triple("geometric_abstract", "Geometric Grid Pattern (نمط هندسي)", listOf(Color(0xFF09171C), Color(0xFF00A884)))
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = WhatsAppSurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Chat Wallpaper",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Text(
                    text = "Select a predefined abstract pattern or solid emerald-themed gradient for this conversation.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(wallpapers, key = { it.first }) { item ->
                        val key = item.first
                        val title = item.second
                        val previewColors = item.third
                        val isSelected = currentWallpaper == key

                        WallpaperOptionCard(
                            title = title,
                            previewColors = previewColors,
                            isSelected = isSelected,
                            onClick = {
                                onSelectWallpaper(key)
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Done", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun WallpaperOptionCard(
    title: String,
    previewColors: List<Color>,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("wallpaper_option_$title"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = WhatsAppSurfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Brush.linearGradient(previewColors))
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f)
            )
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(EmeraldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✓", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: Message,
    isSentByMe: Boolean,
    isGroup: Boolean,
    onImageClick: (String) -> Unit,
    onLongClick: () -> Unit,
    onReactionClick: (String) -> Unit
) {
    val bubbleColor = if (isSentByMe) BubbleSent else BubbleReceived
    val align = if (isSentByMe) Alignment.End else Alignment.Start

    // Interactive Audio State
    var isAudioPlaying by remember { mutableStateOf(false) }
    var audioProgress by remember { mutableFloatStateOf(0.35f) }
    var playbackSpeed by remember { mutableStateOf("1x") }

    LaunchedEffect(isAudioPlaying) {
        if (isAudioPlaying) {
            while (isAudioPlaying) {
                kotlinx.coroutines.delay(200)
                audioProgress = if (audioProgress >= 1f) 0f else audioProgress + 0.04f
                if (audioProgress >= 1f) {
                    isAudioPlaying = false
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalAlignment = align
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 12.dp,
                topEnd = 12.dp,
                bottomStart = if (isSentByMe) 12.dp else 2.dp,
                bottomEnd = if (isSentByMe) 2.dp else 12.dp
            ),
            colors = CardDefaults.cardColors(containerColor = bubbleColor),
            modifier = Modifier
                .widthIn(min = 80.dp, max = 310.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = { onLongClick() }
                    )
                }
                .testTag("message_bubble_${message.id}")
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                // Group sender name if received in group
                if (isGroup && !isSentByMe && message.senderName.isNotEmpty()) {
                    val nameColors = listOf(
                        Color(0xFFE52875),
                        Color(0xFF25D366),
                        Color(0xFF53BDEB),
                        Color(0xFFFFB703),
                        Color(0xFFBB86FC)
                    )
                    val colorIndex = Math.abs(message.senderName.hashCode()) % nameColors.size
                    Text(
                        text = message.senderName,
                        color = nameColors[colorIndex],
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }

                // Reply preview quotation
                if (message.replyToText.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = BubbleDirectReply.copy(alpha = 0.5f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                    ) {
                        Row(modifier = Modifier.padding(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(24.dp)
                                    .background(EmeraldLight, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = message.replyToSender.ifEmpty { "Reply" },
                                    color = EmeraldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = message.replyToText,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Content based on MessageType
                when (message.type) {
                    MessageType.IMAGE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onImageClick(message.mediaUrl.ifEmpty { message.mediaLocalUri }) }
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(message.mediaUrl.ifEmpty { message.mediaLocalUri })
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "Media image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp),
                                contentScale = ContentScale.Crop
                            )
                        }
                        if (message.text.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = message.text,
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        }
                    }

                    MessageType.AUDIO -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(EmeraldPrimary, CircleShape)
                                    .clickable { isAudioPlaying = !isAudioPlaying },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isAudioPlaying) "Pause" else "Play",
                                    tint = Color.Black,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                // Animated Voice Waveform Simulator
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(24.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    val barHeights = listOf(8, 14, 20, 12, 18, 22, 10, 16, 24, 14, 8, 18, 22, 12, 16, 20, 10, 14, 8, 16)
                                    barHeights.forEachIndexed { index, height ->
                                        val isPassed = (index.toFloat() / barHeights.size) <= audioProgress
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(height.dp)
                                                .background(
                                                    if (isPassed) EmeraldPrimary else EmeraldLight.copy(alpha = 0.35f),
                                                    RoundedCornerShape(2.dp)
                                                )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isAudioPlaying) "0:${(audioProgress * 18).toInt().toString().padStart(2, '0')}" else "0:18",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(WhatsAppSurfaceVariant, RoundedCornerShape(10.dp))
                                            .clickable {
                                                playbackSpeed = when (playbackSpeed) {
                                                    "1x" -> "1.5x"
                                                    "1.5x" -> "2x"
                                                    else -> "1x"
                                                }
                                            }
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = playbackSpeed,
                                            color = EmeraldLight,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    MessageType.DOCUMENT -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(WhatsAppSurfaceVariant, RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = "Document",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(30.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = message.mediaFileName.ifEmpty { "Document.pdf" },
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${message.mediaSize.ifEmpty { "1.4 MB" }} • PDF",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    else -> {
                        // Standard text
                        Text(
                            text = message.text,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            lineHeight = 20.sp
                        )
                    }
                }

                // Timestamp & Status Row with Real-Time Read Receipts
                val effectiveStatus = when {
                    !isSentByMe -> message.status
                    message.status == MessageStatus.READ || message.readBy.any { it != message.senderId } -> MessageStatus.READ
                    message.status == MessageStatus.DELIVERED -> MessageStatus.DELIVERED
                    else -> message.status
                }

                Row(
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = formatMessageTime(message.timestamp),
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    if (isSentByMe) {
                        ReadReceiptIcon(status = effectiveStatus, size = 15.dp)
                    }
                }
            }
        }

        // Message Reactions attached beneath bubble
        if (message.reactions.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 4.dp, vertical = 2.dp)
                    .background(WhatsAppSurfaceContainer, RoundedCornerShape(12.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                message.reactions.values.distinct().forEach { emoji ->
                    Text(
                        text = emoji,
                        fontSize = 13.sp,
                        modifier = Modifier.clickable { onReactionClick(emoji) }
                    )
                }
            }
        }
    }
}

@Composable
fun ChatInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    onEmojiClick: () -> Unit,
    onSend: () -> Unit,
    onAttachClick: () -> Unit,
    onCameraClick: () -> Unit,
    onVoiceRecord: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = WhatsAppSurfaceVariant,
            modifier = Modifier.weight(1f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onEmojiClick,
                    modifier = Modifier.size(36.dp).testTag("chat_emoji_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEmotions,
                        contentDescription = "Emoji",
                        tint = TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                BasicTextField(
                    value = text,
                    onValueChange = onTextChange,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp, vertical = 8.dp)
                        .testTag("chat_text_input"),
                    textStyle = TextStyle(
                        color = TextPrimary,
                        fontSize = 16.sp
                    ),
                    cursorBrush = SolidColor(EmeraldPrimary),
                    decorationBox = { innerTextField ->
                        if (text.isEmpty()) {
                            Text(
                                text = "Message",
                                color = TextMuted,
                                fontSize = 16.sp
                            )
                        }
                        innerTextField()
                    }
                )

                IconButton(
                    onClick = onAttachClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("chat_attach_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Attach",
                        tint = TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                if (text.isEmpty()) {
                    IconButton(
                        onClick = onCameraClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("chat_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Camera",
                            tint = TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Send or Voice Record FAB
        FloatingActionButton(
            onClick = {
                if (text.isNotBlank()) onSend() else onVoiceRecord()
            },
            containerColor = EmeraldPrimary,
            contentColor = Color.Black,
            shape = CircleShape,
            modifier = Modifier
                .size(48.dp)
                .testTag("chat_send_button")
        ) {
            Icon(
                imageVector = if (text.isNotBlank()) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                contentDescription = if (text.isNotBlank()) "Send" else "Voice record",
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun AttachmentOptionItem(
    icon: ImageVector,
    label: String,
    backgroundColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(backgroundColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun MessageInfoDialog(
    message: Message,
    chat: Chat?,
    currentUser: com.example.data.models.User?,
    onDismiss: () -> Unit
) {
    val isSentByMe = message.senderId == currentUser?.uid
    val effectiveStatus = when {
        message.status == MessageStatus.READ || message.readBy.any { it != message.senderId } -> MessageStatus.READ
        message.status == MessageStatus.DELIVERED -> MessageStatus.DELIVERED
        else -> message.status
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = WhatsAppSurface,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Message Info",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Message sample bubble
                Surface(
                    color = if (isSentByMe) BubbleSent else BubbleReceived,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        if (message.text.isNotEmpty()) {
                            Text(text = message.text, color = TextPrimary, fontSize = 14.sp)
                        } else if (message.type != MessageType.TEXT) {
                            Text(text = "Media: ${message.mediaFileName.ifEmpty { message.type.name }}", color = TextPrimary, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = formatMessageTime(message.timestamp),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.End)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Read Receipt status indicator
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReadReceiptIcon(status = MessageStatus.READ, size = 20.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Read", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        val readTime = message.readTimestamps.values.firstOrNull() ?: if (effectiveStatus == MessageStatus.READ) message.timestamp + 1800L else null
                        Text(
                            text = if (effectiveStatus == MessageStatus.READ && readTime != null) formatDetailTimestamp(readTime) else if (effectiveStatus == MessageStatus.READ) "Read in real-time" else "Not read yet",
                            color = if (effectiveStatus == MessageStatus.READ) EmeraldLight else TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }

                HorizontalDivider(color = DividerColor.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))

                // Delivered status indicator
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReadReceiptIcon(status = MessageStatus.DELIVERED, size = 20.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Delivered", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        val deliveredTime = message.deliveredTimestamps.values.firstOrNull() ?: (message.timestamp + 600L)
                        Text(
                            text = if (effectiveStatus == MessageStatus.DELIVERED || effectiveStatus == MessageStatus.READ) formatDetailTimestamp(deliveredTime) else "Pending delivery",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                // If group chat, show who read it
                if (chat?.isGroup == true && message.readBy.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Read by (${message.readBy.size})",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        message.readBy.forEach { readerId ->
                            val readerName = if (readerId == currentUser?.uid) "You" else chat.participantNames[readerId] ?: "Participant"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(
                                    photoUrl = chat.participantPhotos[readerId] ?: "",
                                    displayName = readerName,
                                    size = 32.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(text = readerName, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                Icon(
                                    imageVector = Icons.Default.DoneAll,
                                    contentDescription = "Read",
                                    tint = ReadTickBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
