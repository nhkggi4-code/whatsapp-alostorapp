package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PaintingStyle.Companion.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.models.MessageStatus
import com.example.ui.theme.DarkInputBackground
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.ReadTickBlue
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhatsAppBackground
import com.example.ui.theme.WhatsAppSurface
import com.example.ui.theme.WhatsAppSurfaceVariant
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UserAvatar(
    photoUrl: String,
    displayName: String,
    modifier: Modifier = Modifier,
    size: Dp = 50.dp,
    isGroup: Boolean = false,
    isOnline: Boolean = false,
    showOnlineIndicator: Boolean = false
) {
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        val isAlostora = displayName.contains("Mohamed", ignoreCase = true) || displayName.contains("الاسطورة") || displayName.contains("Founder")

        if (isAlostora) {
            // High-fidelity Alostora Mohamed avatar
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(WhatsAppSurfaceVariant)
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(id = R.drawable.img_alostora_mohamed),
                    contentDescription = displayName,
                    modifier = Modifier.size(size),
                    contentScale = ContentScale.Crop
                )
            }
        } else if (photoUrl.isNotEmpty()) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(photoUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = displayName,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(WhatsAppSurfaceVariant),
                contentScale = ContentScale.Crop
            )
        } else {
            // Initial letters avatar with gradient color
            val initials = if (displayName.isNotBlank()) {
                displayName.split(" ")
                    .mapNotNull { it.firstOrNull()?.toString() }
                    .take(2)
                    .joinToString("")
                    .uppercase()
            } else if (isGroup) "G" else "U"

            val bgColors = listOf(
                Color(0xFF005C4B),
                Color(0xFF075E54),
                Color(0xFF1F6F8B),
                Color(0xFF28527A),
                Color(0xFF8B005D),
                Color(0xFF6B4E71)
            )
            val colorIndex = Math.abs(displayName.hashCode()) % bgColors.size
            val bgColor = bgColors[colorIndex]

            Box(
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(bgColor),
                contentAlignment = Alignment.Center
            ) {
                if (isGroup && initials.length <= 1) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = "Group",
                        tint = TextPrimary,
                        modifier = Modifier.size(size * 0.55f)
                    )
                } else {
                    Text(
                        text = initials,
                        color = Color.White,
                        fontSize = (size.value * 0.4f).sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        if (showOnlineIndicator && isOnline) {
            Box(
                modifier = Modifier
                    .size(size * 0.28f)
                    .align(Alignment.BottomEnd)
                    .background(Color(0xFF25D366), CircleShape)
                    .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun StatusRingAvatar(
    photoUrl: String,
    displayName: String,
    itemCount: Int,
    hasUnseen: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .size(size)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        val ringColor = if (hasUnseen) EmeraldPrimary else TextMuted
        val strokeWidth = 2.5.dp

        if (itemCount > 1) {
            // Segmented ring
            Canvas(modifier = Modifier.size(size)) {
                val count = itemCount.coerceAtLeast(1)
                val sweep = (360f - (count * 6f)) / count
                for (i in 0 until count) {
                    val startAngle = -90f + i * (sweep + 6f) + 3f
                    drawArc(
                        color = ringColor,
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        } else {
            // Continuous ring
            Canvas(modifier = Modifier.size(size)) {
                drawCircle(
                    color = ringColor,
                    style = Stroke(width = strokeWidth.toPx())
                )
            }
        }

        UserAvatar(
            photoUrl = photoUrl,
            displayName = displayName,
            size = size - 8.dp
        )
    }
}

@Composable
fun ReadReceiptIcon(
    status: MessageStatus,
    modifier: Modifier = Modifier,
    size: Dp = 15.dp
) {
    when (status) {
        MessageStatus.SENDING -> {
            Box(
                modifier = modifier
                    .size(size * 0.7f)
                    .border(1.dp, TextSecondary, CircleShape)
            )
        }
        MessageStatus.SENT -> {
            Icon(
                imageVector = Icons.Default.Done,
                contentDescription = "Sent",
                tint = TextSecondary,
                modifier = modifier.size(size)
            )
        }
        MessageStatus.DELIVERED -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "Delivered",
                tint = TextSecondary,
                modifier = modifier.size(size)
            )
        }
        MessageStatus.READ -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "Read",
                tint = ReadTickBlue,
                modifier = modifier.size(size)
            )
        }
    }
}

@Composable
fun DateHeaderPill(
    timestamp: Long,
    modifier: Modifier = Modifier
) {
    val dateText = formatTimestampToHeader(timestamp)
    Box(
        modifier = modifier
            .padding(vertical = 8.dp)
            .background(DarkInputBackground.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = dateText,
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

fun formatTimestampToHeader(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    val oneDay = 24 * 60 * 60 * 1000L

    return when {
        diff < oneDay -> "TODAY"
        diff < 2 * oneDay -> "YESTERDAY"
        else -> SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date(timestamp)).uppercase()
    }
}

fun formatChatTime(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    val oneDay = 24 * 60 * 60 * 1000L

    return when {
        diff < oneDay -> SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(timestamp))
        diff < 2 * oneDay -> "Yesterday"
        diff < 7 * oneDay -> SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(timestamp))
        else -> SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(timestamp))
    }
}

fun formatMessageTime(timestamp: Long): String {
    return SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(timestamp))
}

fun formatDetailTimestamp(timestamp: Long): String {
    return SimpleDateFormat("h:mm:ss a • dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
}

@Composable
fun ActiveCallDialog(
    callerName: String,
    callerPhoto: String,
    isVideo: Boolean,
    onDismiss: () -> Unit
) {
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(true) }
    var isCameraOff by remember { mutableStateOf(false) }
    var callSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            callSeconds++
        }
    }

    val callTimeFormatted = remember(callSeconds) {
        val mins = callSeconds / 60
        val secs = callSeconds % 60
        "%02d:%02d".format(mins, secs)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = WhatsAppBackground,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Info
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 40.dp)
                ) {
                    Text(
                        text = callerName,
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (callSeconds < 2) "Connecting..." else "WhatsApp ${if (isVideo) "Video" else "Audio"} Call • $callTimeFormatted",
                        color = EmeraldLight,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "🔒 End-to-end encrypted",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }

                // Center Avatar with pulsating green ring
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier
                            .size(170.dp)
                            .background(EmeraldContainer.copy(alpha = 0.5f), CircleShape)
                    )
                    UserAvatar(
                        photoUrl = callerPhoto,
                        displayName = callerName,
                        size = 140.dp
                    )
                }

                // Bottom Call Controls
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Speaker Button
                        IconButton(
                            onClick = { isSpeakerOn = !isSpeakerOn },
                            modifier = Modifier
                                .size(56.dp)
                                .background(if (isSpeakerOn) WhatsAppSurfaceVariant else EmeraldPrimary, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isSpeakerOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                                contentDescription = "Speaker",
                                tint = if (isSpeakerOn) TextPrimary else DarkOnPrimary
                            )
                        }

                        if (isVideo) {
                            // Video Camera Toggle
                            IconButton(
                                onClick = { isCameraOff = !isCameraOff },
                                modifier = Modifier
                                .size(56.dp)
                                .background(if (isCameraOff) WhatsAppSurfaceVariant else EmeraldPrimary, CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isCameraOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
                                    contentDescription = "Video",
                                    tint = if (isCameraOff) TextPrimary else DarkOnPrimary
                                )
                            }
                        }

                        // Mute Button
                        IconButton(
                            onClick = { isMuted = !isMuted },
                            modifier = Modifier
                                .size(56.dp)
                                .background(if (isMuted) Color(0xFFEF5350) else WhatsAppSurfaceVariant, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = TextPrimary
                            )
                        }
                    }

                    // End Call FAB
                    FloatingActionButton(
                        onClick = onDismiss,
                        containerColor = Color(0xFFE53935),
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(64.dp)
                            .testTag("btn_end_call")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "End Call",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmojiStickerSheet(
    onEmojiSelected: (String) -> Unit,
    onStickerSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    val emojis = listOf(
        "😂", "❤️", "🔥", "👍", "👑", "✨", "🚀", "⚡",
        "🎉", "💯", "🤲", "☕", "🌟", "💡", "💎", "🏆",
        "😍", "🙏", "💪", "😎", "🤝", "👌", "👏", "🤩",
        "😇", "🌙", "⭐", "🎯", "🛡️", "🔑", "🕊️", "🖤"
    )

    val stickers = listOf(
        "👑 Alostora Mohamed",
        "🚀 Ultra Speed",
        "💚 Pure Emerald",
        "⚡ VIP Club",
        "🌟 Golden Star",
        "🔥 Fire Coder",
        "☕ Coffee & Code",
        "💎 Diamond Member",
        "🛡️ 100% Encrypted",
        "🏆 Top Legend"
    )

    Surface(
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color = WhatsAppSurface,
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = EmeraldPrimary,
                    modifier = Modifier.weight(1f),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = EmeraldPrimary,
                            height = 2.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("EMOJIS", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("STICKERS", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            if (selectedTab == 0) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(8),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(emojis) { emoji ->
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onEmojiSelected(emoji) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 24.sp)
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(stickers) { sticker ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .background(WhatsAppSurfaceVariant, RoundedCornerShape(12.dp))
                                .clickable { onStickerSelected(sticker) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = sticker,
                                color = GoldAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
