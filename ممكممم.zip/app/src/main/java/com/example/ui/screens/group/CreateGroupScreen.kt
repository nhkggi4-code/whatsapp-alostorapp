package com.example.ui.screens.group

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.models.User
import com.example.data.repository.ChatRepository
import com.example.ui.components.UserAvatar
import com.example.ui.theme.DarkInputBackground
import com.example.ui.theme.DividerColor
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhatsAppBackground
import com.example.ui.theme.WhatsAppSurface
import com.example.ui.theme.WhatsAppSurfaceVariant

@Composable
fun CreateGroupScreen(
    repository: ChatRepository,
    onBack: () -> Unit,
    onGroupCreated: (String) -> Unit
) {
    val allUsers by repository.allUsers.collectAsState()
    val currentUser by repository.currentUser.collectAsState()
    val selectableUsers = remember(allUsers, currentUser) {
        allUsers.filter { it.uid != currentUser?.uid }
    }

    val selectedUsers = remember { mutableStateListOf<User>() }
    var groupName by remember { mutableStateOf("") }
    var groupDescription by remember { mutableStateOf("") }
    var groupPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var step by remember { mutableStateOf(1) } // 1: Pick members, 2: Group name & description

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        groupPhotoUri = uri
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("create_group_screen"),
        containerColor = WhatsAppBackground,
        topBar = {
            Surface(color = WhatsAppSurface, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        if (step == 2) step = 1 else onBack()
                    }, modifier = Modifier.testTag("create_group_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = if (step == 1) "New group" else "Group Details",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (step == 1) "${selectedUsers.size} of ${selectableUsers.size} selected" else "Provide group subject and description",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (step == 1 && selectedUsers.isNotEmpty()) {
                FloatingActionButton(
                    onClick = { step = 2 },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.Black,
                    shape = CircleShape,
                    modifier = Modifier.testTag("btn_next_group_details")
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Next")
                }
            }
        }
    ) { innerPadding ->
        if (step == 1) {
            // STEP 1: SELECT CONTACTS
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Selected contacts chips
                if (selectedUsers.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WhatsAppSurfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(selectedUsers, key = { it.uid }) { user ->
                            Box(contentAlignment = Alignment.TopEnd) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    UserAvatar(photoUrl = user.photoUrl, displayName = user.displayName, size = 44.dp)
                                    Text(
                                        text = user.displayName.split(" ").firstOrNull() ?: "",
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(Color.Gray, CircleShape)
                                        .clickable { selectedUsers.remove(user) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(12.dp))
                                }
                            }
                        }
                    }
                    HorizontalDivider(color = DividerColor)
                }

                // Users list
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(selectableUsers, key = { it.uid }) { user ->
                        val isSelected = selectedUsers.contains(user)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isSelected) selectedUsers.remove(user) else selectedUsers.add(user)
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .testTag("select_user_${user.uid}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatar(photoUrl = user.photoUrl, displayName = user.displayName, size = 48.dp)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = user.displayName, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text(text = user.about, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                            }
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = { checked ->
                                    if (checked) selectedUsers.add(user) else selectedUsers.remove(user)
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = EmeraldPrimary,
                                    checkmarkColor = Color.Black,
                                    uncheckedColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        } else {
            // STEP 2: GROUP NAME & DESCRIPTION
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Group Icon Selector
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(WhatsAppSurfaceVariant)
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .testTag("group_icon_picker"),
                    contentAlignment = Alignment.Center
                ) {
                    if (groupPhotoUri != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(groupPhotoUri)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Group icon",
                            modifier = Modifier.size(90.dp),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Add Photo", tint = EmeraldPrimary, modifier = Modifier.size(32.dp))
                            Text("Icon", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = groupName,
                    onValueChange = { groupName = it },
                    label = { Text("Group Subject / Name") },
                    placeholder = { Text("e.g. Alostora VIP Innovators 🚀") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = DarkInputBackground,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = WhatsAppSurfaceVariant,
                        unfocusedContainerColor = WhatsAppSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_name_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = groupDescription,
                    onValueChange = { groupDescription = it },
                    label = { Text("Group Description (Optional)") },
                    placeholder = { Text("Group goals and welcome message...") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = DarkInputBackground,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = WhatsAppSurfaceVariant,
                        unfocusedContainerColor = WhatsAppSurfaceVariant
                    ),
                    minLines = 3,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("group_desc_input")
                )

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    onClick = {
                        val name = if (groupName.isBlank()) "New Group" else groupName
                        repository.createGroup(
                            name = name,
                            description = groupDescription,
                            selectedUsers = selectedUsers,
                            groupPhotoUri = groupPhotoUri
                        ) { newGroupId ->
                            onGroupCreated(newGroupId)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_create_group_confirm")
                ) {
                    Text(
                        text = "Create Group (${selectedUsers.size + 1} Members)",
                        color = Color.Black,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
