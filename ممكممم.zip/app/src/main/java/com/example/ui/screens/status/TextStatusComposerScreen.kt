package com.example.ui.screens.status

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.models.StatusType
import com.example.data.repository.ChatRepository
import com.example.ui.theme.EmeraldPrimary

@Composable
fun TextStatusComposerScreen(
    repository: ChatRepository,
    onBack: () -> Unit,
    onPosted: () -> Unit
) {
    val bgColors = remember {
        listOf(
            0xFF005C4BL, // WhatsApp Dark Emerald
            0xFF075E54L, // Forest Emerald
            0xFF512DA8L, // Royal Purple
            0xFF00796BL, // Teal
            0xFFD84315L, // Deep Orange
            0xFF880E4FL, // Crimson Red
            0xFF1A237EL, // Navy Blue
            0xFF263238L  // Charcoal
        )
    }

    val fontFamilies = remember {
        listOf(
            FontFamily.Default,
            FontFamily.Serif,
            FontFamily.Cursive,
            FontFamily.Monospace
        )
    }

    var selectedColorIndex by remember { mutableIntStateOf(0) }
    var selectedFontIndex by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf("") }
    var mediaUri by remember { mutableStateOf<Uri?>(null) }
    var mediaCaption by remember { mutableStateOf("") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            mediaUri = uri
        }
    }

    val currentColor = Color(bgColors[selectedColorIndex])
    val currentFont = fontFamilies[selectedFontIndex]

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(currentColor)
            .imePadding()
            .testTag("text_status_composer_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Controls Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("status_composer_back")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Pick Photo
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = "Add Photo", tint = Color.White)
                    }

                    // Cycle Font
                    IconButton(
                        onClick = {
                            selectedFontIndex = (selectedFontIndex + 1) % fontFamilies.size
                        },
                        modifier = Modifier.testTag("btn_cycle_font")
                    ) {
                        Icon(Icons.Default.TextFields, contentDescription = "Change Font", tint = Color.White)
                    }

                    // Cycle Color
                    IconButton(
                        onClick = {
                            selectedColorIndex = (selectedColorIndex + 1) % bgColors.size
                        },
                        modifier = Modifier.testTag("btn_cycle_color")
                    ) {
                        Icon(Icons.Default.ColorLens, contentDescription = "Change Color", tint = Color.White)
                    }
                }
            }

            // Main Editor Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                if (mediaUri != null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(mediaUri)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Media status preview",
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        BasicTextField(
                            value = mediaCaption,
                            onValueChange = { mediaCaption = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            textStyle = TextStyle(
                                color = Color.White,
                                fontSize = 16.sp
                            ),
                            cursorBrush = SolidColor(EmeraldPrimary),
                            decorationBox = { inner ->
                                if (mediaCaption.isEmpty()) {
                                    Text("Add a caption...", color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
                                }
                                inner()
                            }
                        )
                    }
                } else {
                    BasicTextField(
                        value = statusText,
                        onValueChange = { statusText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("status_text_input"),
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = currentFont,
                            textAlign = TextAlign.Center,
                            lineHeight = 38.sp
                        ),
                        cursorBrush = SolidColor(EmeraldPrimary),
                        decorationBox = { innerTextField ->
                            if (statusText.isEmpty()) {
                                Text(
                                    text = "Type a status update...",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = currentFont,
                                    textAlign = TextAlign.Center
                                )
                            }
                            innerTextField()
                        }
                    )
                }
            }

            // Bottom Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FloatingActionButton(
                    onClick = {
                        if (mediaUri != null) {
                            repository.postStatus(
                                type = StatusType.IMAGE,
                                content = mediaUri.toString(),
                                caption = mediaCaption,
                                mediaUri = mediaUri
                            ) {
                                onPosted()
                            }
                        } else if (statusText.isNotBlank()) {
                            repository.postStatus(
                                type = StatusType.TEXT,
                                content = statusText.trim(),
                                backgroundColor = bgColors[selectedColorIndex],
                                fontIndex = selectedFontIndex
                            ) {
                                onPosted()
                            }
                        }
                    },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.Black,
                    shape = CircleShape,
                    modifier = Modifier.testTag("btn_send_status")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Post Status",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
