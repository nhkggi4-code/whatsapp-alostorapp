package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WhatsApp Dark Theme & Emerald Accents
val EmeraldPrimary = Color(0xFF00A884)
val EmeraldLight = Color(0xFF25D366)
val EmeraldDark = Color(0xFF075E54)
val EmeraldContainer = Color(0xFF005C4B)
val GoldAccent = Color(0xFFFFB703)

// WhatsApp Dark Backgrounds & Surfaces
val WhatsAppBackground = Color(0xFF0B141B)
val WhatsAppSurface = Color(0xFF121B22)
val WhatsAppSurfaceVariant = Color(0xFF202C33)
val WhatsAppSurfaceContainer = Color(0xFF2A3942)
val WhatsAppCardBackground = Color(0xFF1F2C34)

// Message Bubbles
val BubbleSent = Color(0xFF005C4B)
val BubbleReceived = Color(0xFF202C33)
val BubbleDirectReply = Color(0xFF054740)

// Text Colors
val TextPrimary = Color(0xFFE9EDEF)
val TextSecondary = Color(0xFF8696A0)
val TextMuted = Color(0xFF667781)
val TextAccent = Color(0xFF53BDEB) // WhatsApp Blue ticks

// System / Utility
val ReadTickBlue = Color(0xFF53BDEB)
val UnreadBadgeGreen = Color(0xFF00A884)
val DarkOnPrimary = Color(0xFF0B141B)
val OnlineGreen = Color(0xFF25D366)
val DangerRed = Color(0xFFEA4335)
val DividerColor = Color(0xFF202C33)
val DarkInputBackground = Color(0xFF2A3942)

