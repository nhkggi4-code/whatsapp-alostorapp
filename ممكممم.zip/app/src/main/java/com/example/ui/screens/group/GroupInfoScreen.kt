package com.example.ui.screens.group

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.User
import com.example.data.repository.ChatRepository
import com.example.ui.components.UserAvatar
import com.example.ui.theme.DividerColor
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhatsAppBackground
import com.example.ui.theme.WhatsAppSurface
import com.example.ui.theme.WhatsAppSurfaceVariant

@Composable
fun GroupInfoScreen(
    chatId: String,
    repository: ChatRepository,
    onBack: () -> Unit,
    onExitGroupSuccess: () -> Unit
) {
    val chats by repository.chats.collectAsState()
    val allUsers by repository.allUsers.collectAsState()
    val currentUser by repository.currentUser.collectAsState()

    val chat = remember(chats, chatId) { chats.find { it.id == chatId } }

    var showAddParticipantDialog by remember { mutableStateOf(false) }
    var selectedUserForRemoval by remember { mutableStateOf<String?>(null) }
    var showExitDialog by remember { mutableStateOf(false) }

    if (chat == null) {
        onBack()
        return
    }

    val isAdmin = chat.adminIds.contains(currentUser?.uid)

    // Filter contacts not yet in group
    val availableUsersToAdd = remember(allUsers, chat.participantIds) {
        allUsers.filter { !chat.participantIds.contains(it.uid) }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("group_info_screen"),
        containerColor = WhatsAppBackground,
        topBar = {
            Surface(color = WhatsAppSurface, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("group_info_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Group info",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 40.dp)
        ) {
            // Group Hero Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(WhatsAppSurfaceVariant)
                        .padding(vertical = 24.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    UserAvatar(
                        photoUrl = chat.photoUrl,
                        displayName = chat.name,
                        size = 96.dp,
                        isGroup = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = chat.name,
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Group • ${chat.participantIds.size} participants",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
            }

            // Description Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhatsAppSurfaceVariant),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Group description",
                            color = EmeraldPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = chat.description.ifEmpty { "No description provided." },
                            color = TextPrimary,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
            }

            // Participants Header & Add Button
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhatsAppSurfaceVariant),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(top = 16.dp)) {
                        Text(
                            text = "${chat.participantIds.size} participants",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                        )

                        // Add Participants Action
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showAddParticipantDialog = true }
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .testTag("btn_add_participant"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(EmeraldPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.GroupAdd, contentDescription = "Add", tint = Color.Black)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Text(
                                text = "Add participants",
                                color = EmeraldPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        HorizontalDivider(color = DividerColor)
                    }
                }
            }

            // Participant Items
            items(chat.participantIds, key = { it }) { participantId ->
                val pName = chat.participantNames[participantId] ?: if (participantId == currentUser?.uid) "You" else "Member"
                val pPhoto = chat.participantPhotos[participantId] ?: ""
                val isPAdmin = chat.adminIds.contains(participantId)
                val isMe = participantId == currentUser?.uid

                var showItemMenu by remember { mutableStateOf(false) }

                Surface(
                    color = WhatsAppSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isAdmin && !isMe) showItemMenu = true
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .testTag("group_participant_$participantId"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(photoUrl = pPhoto, displayName = pName, size = 46.dp)

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isMe) "$pName (You)" else pName,
                                    color = TextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (participantId == "alostora_founder") {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.Default.Star, contentDescription = "Founder", tint = GoldAccent, modifier = Modifier.size(14.dp))
                                }
                            }
                            Text(
                                text = if (isMe) "Available" else "Group Member",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        if (isPAdmin) {
                            Box(
                                modifier = Modifier
                                    .background(EmeraldContainer, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Group Admin",
                                    color = EmeraldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (isAdmin && !isMe) {
                            Box {
                                IconButton(onClick = { showItemMenu = true }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "Manage", tint = TextSecondary)
                                }
                                DropdownMenu(
                                    expanded = showItemMenu,
                                    onDismissRequest = { showItemMenu = false },
                                    modifier = Modifier.background(WhatsAppSurface)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Remove $pName", color = MaterialTheme.colorScheme.error) },
                                        leadingIcon = { Icon(Icons.Default.PersonRemove, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                        onClick = {
                                            showItemMenu = false
                                            repository.removeGroupMember(chatId, participantId)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Exit / Delete Group
            item {
                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = WhatsAppSurfaceVariant),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showExitDialog = true }
                            .padding(16.dp)
                            .testTag("btn_exit_group"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Exit",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Exit group",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    // Add Participant Dialog
    if (showAddParticipantDialog) {
        AlertDialog(
            onDismissRequest = { showAddParticipantDialog = false },
            title = { Text("Add Participant", color = TextPrimary) },
            text = {
                if (availableUsersToAdd.isEmpty()) {
                    Text("All your available contacts are already in this group.", color = TextSecondary)
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp)) {
                        items(availableUsersToAdd, key = { it.uid }) { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        repository.addGroupMember(chatId, user)
                                        showAddParticipantDialog = false
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(photoUrl = user.photoUrl, displayName = user.displayName, size = 40.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(user.displayName, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                    Text(user.about, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddParticipantDialog = false }) {
                    Text("Cancel", color = EmeraldPrimary)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }

    // Exit Group Confirmation
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text("Exit \"${chat.name}\"?", color = TextPrimary) },
            text = { Text("You will no longer be able to send messages in this group.", color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    showExitDialog = false
                    currentUser?.let { repository.removeGroupMember(chatId, it.uid) }
                    onExitGroupSuccess()
                }) {
                    Text("Exit", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = WhatsAppSurfaceVariant
        )
    }
}
