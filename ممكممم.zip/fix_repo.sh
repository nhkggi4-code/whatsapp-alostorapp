#!/bin/bash
sed -i 's/fun fastDemoLogin(onComplete: (Boolean, String?) -> Unit)/fun fastDemoLogin(name: String, about: String)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun sendMessage(chatId: String, text: String, type: MessageType, mediaUri: String?, mediaFileName: String?, replyTo: Message?)/fun sendMessage(chatId: String, text: String, type: MessageType = MessageType.TEXT, mediaUri: android.net.Uri? = null, mediaFileName: String? = null, replyTo: Message? = null)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun createGroup(name: String, description: String, participantIds: List<String>)/fun createGroup(name: String, description: String, selectedUsers: List<User>, groupPhotoUri: android.net.Uri?, onComplete: (Boolean) -> Unit)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun addGroupMember(groupId: String, memberId: String)/fun addGroupMember(groupId: String, user: User)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun getOrCreateAiChat(): String/fun getOrCreateAiChat(onComplete: (String) -> Unit)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun updateProfile(name: String, about: String, phone: String, photoUri: String?)/fun updateProfile(displayName: String, about: String, phoneNumber: String, photoUri: android.net.Uri?, onComplete: () -> Unit)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun markStatusViewed(statusId: String)/fun markStatusViewed(statusId: String, authorId: String)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

sed -i 's/fun postStatus(type: StatusType, content: String, caption: String, backgroundColor: Long, fontIndex: Int)/fun postStatus(type: StatusType, content: String = "", mediaUri: android.net.Uri? = null, backgroundColor: Long = 0L, fontIndex: Int = 0, caption: String = "", onComplete: () -> Unit)/g' app/src/main/java/com/example/data/repository/ChatRepository.kt

